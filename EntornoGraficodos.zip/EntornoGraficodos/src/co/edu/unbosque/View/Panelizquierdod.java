package co.edu.unbosque.View;

import java.awt.Color;

import javax.swing.JPanel;

public class PanelIzquierdod extends JPanel {
public PanelIzquierdod() {
	// TODO Auto-generated constructor stub

	this.setBounds(0,0,400,200);
	this.setBackground(new Color(66, 111, 245));
	

}

}
