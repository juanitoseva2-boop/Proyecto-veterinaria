package co.edu.unbosque.View;

import java.awt.Color;

import javax.swing.JPanel;

public class PanelDerecho extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9090456994551992432L;
	
	public PanelDerecho() {
		this.setBounds(0,0,800,500);
		this.setBackground(Color.MAGENTA);
		
	}
	

}
