package co.edu.unbosque.View;

import java.awt.Color;

import javax.swing.JPanel;

public class PanelDerechodod extends JPanel{
	public PanelDerechodod() {
		this.setLayout(null);
		this.setBounds(0,0,400,200);
		this.setBackground(new Color(66, 111, 245));
		
	

}
}
