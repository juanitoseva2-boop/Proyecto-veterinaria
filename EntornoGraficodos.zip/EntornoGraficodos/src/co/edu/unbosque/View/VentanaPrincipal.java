package co.edu.unbosque.View;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PanelIzquierdo pi;
	private PanelDerecho pd;
	private PanelIzquierdod pido;
	private PanelDerechodod pdo;
	public VentanaPrincipal() {
		configurarVentana();
		pi = new PanelIzquierdo();
		pd = new PanelDerecho();
		pido = new PanelIzquierdod();
		pdo = new PanelDerechodod();
		
		
	
	}

	public void configurarVentana() {
		setTitle("Ventana Principal");
		setBounds(10, 10, 800, 800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		pi = new PanelIzquierdo();
		pd = new PanelDerecho();
		pido = new PanelIzquierdod();
		pdo = new PanelDerechodod();
		
		
		add(pi);
		add(pd);
		add(pdo);
		add(pido);
		
		
	}
	public void configurarComponentes() {
		pi.setVisible(true);
		pd.setVisible(true);
		pdo.setVisible(true);
		pido.setVisible(true);
		
		add(pi);
		add(pd);
		add(pdo);
		add(pido);
		
	}
	
	
}
