package co.edu.unbosque.View;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelIzquierdo extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5136268252820692135L;

	private JButton btn1;
	private JButton btn2;

	public PanelIzquierdo() {
		this.setLayout(null);
		this.setBounds(0, 0, 400, 800);//
		this.setBackground(new Color(66, 245, 93));
		btn1 = new JButton();
		btn2 = new JButton();
		configurarComponentes();
	}

	public void configurarComponentes() {
		btn1.setText("Boton 1");
		btn1.setForeground(new Color(245, 120, 66));
		btn1.setBounds(0, 0, 300, 200);
		btn1.setBounds(125, 290, 150, 40);
		add(btn1);

		btn2.setText("Boton 2");
		btn2.setBounds(0, 500, 100, 40);
		add(btn2);

	}

}
