package co.edu.unbosque.Controller;


import co.edu.unbosque.View.VentanaPrincipal;

public class Controller  {

	private VentanaPrincipal vp;

	public Controller() {
		

	}

	public void arrancarGui() {
		vp =  new VentanaPrincipal();
		vp.setVisible(true);

	}
}
