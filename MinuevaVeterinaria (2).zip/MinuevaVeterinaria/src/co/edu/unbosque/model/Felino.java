package co.edu.unbosque.model;

import java.io.Serializable;

public  class Felino extends Animal implements AccionNocturna, AccionMontana, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7158323249085807859L;
	private final String TIPO_SANGRE = "Caliente";
	private String colorPelaje;
	private boolean esDomestico;

	public Felino() {
	}

	public Felino(String colorPelaje, boolean esDomestico) {
		this.colorPelaje = colorPelaje;
		this.esDomestico = esDomestico;
	}

	public Felino(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super(nombre, edad, peso, esMacho, especie);
	}

	public Felino(String nombre, int edad, float peso, boolean esMacho, String especie, String colorPelaje,
			boolean esDomestico) {
		super(nombre, edad, peso, esMacho, especie);
		this.colorPelaje = colorPelaje;
		this.esDomestico = esDomestico;
	}

	public String getColorPelaje() {
		return colorPelaje;
	}

	public void setColorPelaje(String colorPelaje) {
		this.colorPelaje = colorPelaje;
	}

	public boolean isEsDomestico() {
		return esDomestico;
	}

	public void setEsDomestico(boolean esDomestico) {
		this.esDomestico = esDomestico;
	}

	public String getTIPO_SANGRE() {
		return TIPO_SANGRE;
	}

	@Override
	public String toString() {
		return super.toString() + " - Felino [TIPO_SANGRE=" + TIPO_SANGRE + ", colorPelaje=" + colorPelaje + ", esDomestico=" + esDomestico
				+ "]";
	}

	public String vision(String tipo) {
		if (tipo.equals("nocturna")) {
			return "Los felinos pueden ver mejor durante la noche";
		} else if (tipo.equals("diurna")) {
			return "los felinos no pueden ver  durante el dia";
		} else {
			return "los felinos pueden ver mejor durante el dia : ";
		}
	}

	@Override
	public String dormir() {
		// TODO Auto-generated method stub
		return "Los felinos suelen dormir en una cama";
	}

	@Override
	public String escalar() {
		// TODO Auto-generated method stub
		return "El felino puede escalar arboles,piedras,muros";
	}

	@Override
	public String respirar() {
		// TODO Auto-generated method stub
		return "Los felinos respiran por la nariz " ;
	}
}
