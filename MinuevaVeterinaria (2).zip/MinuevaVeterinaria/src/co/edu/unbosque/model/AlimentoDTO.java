package co.edu.unbosque.model;

public class AlimentoDTO extends ProductoDTO {
	private String tipoAlimento;
	private int peso;
	private boolean esVegano;

	public AlimentoDTO() {
		// TODO Auto-generated constructor stub
	}

	public AlimentoDTO(String tipoAlimento, int peso, boolean esVegano) {
		super();
		this.tipoAlimento = tipoAlimento;
		this.peso = peso;
		this.esVegano = esVegano;
	}

	public AlimentoDTO(String nombre, String color, float precio, int tamano, String tipoAlimento, int peso,
			boolean esVegano) {
		super(nombre, color, precio, tamano);
		this.tipoAlimento = tipoAlimento;
		this.peso = peso;
		this.esVegano = esVegano;
	}

	public AlimentoDTO(String nombre, String color, float precio, int tamano) {
		super(nombre, color, precio, tamano);
	}

	public String getTipoAlimento() {
		return tipoAlimento;
	}

	public void setTipoAlimento(String tipoAlimento) {
		this.tipoAlimento = tipoAlimento;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public boolean isEsVegano() {
		return esVegano;
	}

	public void setEsVegano(boolean esVegano) {
		this.esVegano = esVegano;
	}

	@Override
	public String toString() {
		return super.toString() + " - Alimento [tipoAlimento=" + tipoAlimento + ", peso=" + peso + ", esVegano=" + esVegano + "]";
	}

}
