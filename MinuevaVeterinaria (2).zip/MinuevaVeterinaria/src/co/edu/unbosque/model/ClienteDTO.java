package co.edu.unbosque.model;

public class ClienteDTO  extends PersonaDTO {
		private String nombreMascota;
		 private String tipoAnimal;
		 
		 public ClienteDTO() {
			// TODO Auto-generated constructor stub
		}

		public ClienteDTO(String nombreMascota, String tipoAnimal) {
			super();
			this.nombreMascota = nombreMascota;
			this.tipoAnimal = tipoAnimal;
		}

		public ClienteDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo,
				String nombreMascota, String tipoAnimal) {
			super(nombre, id, correoElectronico, numeroTelefono, sexo);
			this.nombreMascota = nombreMascota;
			this.tipoAnimal = tipoAnimal;
		}

		public ClienteDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo) {
			super(nombre, id, correoElectronico, numeroTelefono, sexo);
			// TODO Auto-generated constructor stub
		}

		public String getNombreMascota() {
			return nombreMascota;
		}

		public void setNombreMascota(String nombreMascota) {
			this.nombreMascota = nombreMascota;
		}

		public String getTipoAnimal() {
			return tipoAnimal;
		}

		public void setTipoAnimal(String tipoAnimal) {
			this.tipoAnimal = tipoAnimal;
		}

		@Override
		public String toString() {
			return super.toString() + " - Cliente [nombreMascota=" + nombreMascota + ", tipoAnimal=" + tipoAnimal + "]";
		}
		 
	}



