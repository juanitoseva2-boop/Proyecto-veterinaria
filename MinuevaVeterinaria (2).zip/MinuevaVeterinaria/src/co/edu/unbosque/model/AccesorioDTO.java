package co.edu.unbosque.model;

public class AccesorioDTO extends ProductoDTO {

	private String tipoAccesorio;
	private String talla;
	private String parteCuerpo;
	
	public AccesorioDTO() {
		// TODO Auto-generated constructor stub
	}

	public AccesorioDTO(String tipoAccesorio, String talla, String parteCuerpo) {
		super();
		this.tipoAccesorio = tipoAccesorio;
		this.talla = talla;
		this.parteCuerpo = parteCuerpo;
	}

	public AccesorioDTO(String nombre, String color, float precio, int tamano, String tipoAccesorio, String talla,
			String parteCuerpo) {
		super(nombre, color, precio, tamano);
		this.tipoAccesorio = tipoAccesorio;
		this.talla = talla;
		this.parteCuerpo = parteCuerpo;
	}

	public AccesorioDTO(String nombre, String color, float precio, int tamano) {
		super(nombre, color, precio, tamano);
		// TODO Auto-generated constructor stub
	}

	public String getTipoAccesorio() {
		return tipoAccesorio;
	}

	public void setTipoAccesorio(String tipoAccesorio) {
		this.tipoAccesorio = tipoAccesorio;
	}

	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	public String getParteCuerpo() {
		return parteCuerpo;
	}

	public void setParteCuerpo(String parteCuerpo) {
		this.parteCuerpo = parteCuerpo;
	}

	@Override
	public String toString() {
		return super.toString() + " - Accesorio [tipoAccesorio=" + tipoAccesorio + ", talla=" + talla + ", parteCuerpo=" + parteCuerpo + "]";
	}
	
	
 

}
