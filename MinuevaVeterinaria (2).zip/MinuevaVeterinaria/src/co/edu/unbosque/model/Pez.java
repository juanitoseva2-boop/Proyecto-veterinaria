package co.edu.unbosque.model;

import java.io.Serializable;

public class Pez extends Animal implements AccionOvipara, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7863335729097075592L;
	private final String TIPO_SANGRE = "Fria";
	private boolean esVenenoso;
	private float consumoAlimentoDiario;

	public Pez() {
	
	}

	public Pez(boolean esVenenoso, float consumoAlimentoDiario) {
		this.esVenenoso = esVenenoso;
		this.consumoAlimentoDiario = consumoAlimentoDiario;
	}

	public Pez(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super(nombre, edad, peso, esMacho, especie);
	}

	public Pez(String nombre, int edad, float peso, boolean esMacho, String especie, boolean esVenenoso,
			float consumoAlimentoDiario) {
		super(nombre, edad, peso, esMacho, especie);
		this.esVenenoso = esVenenoso;
		this.consumoAlimentoDiario = consumoAlimentoDiario;
	}

	public boolean isEsVenenoso() {
		return esVenenoso;
	}

	public void setEsVenenoso(boolean esVenenoso) {
		this.esVenenoso = esVenenoso;
	}

	public float getConsumoAlimentoDiario() {
		return consumoAlimentoDiario;
	}

	public void setConsumoAlimentoDiario(float consumoAlimentoDiario) {
		this.consumoAlimentoDiario = consumoAlimentoDiario;
	}

	public String getTIPO_SANGRE() {
		return TIPO_SANGRE;
	}

	@Override
	public String toString() {
		return super.toString() + " - Pez [TIPO_SANGRE=" + TIPO_SANGRE + ", esVenenoso=" + esVenenoso + ", consumoAlimentoDiario="
				+ consumoAlimentoDiario + "]";
	}

	public String temperaturaAgua(String temperatura) {
		if (temperatura.equals("fria")) {
			return "El pez necesita una temperatura mas calida";
		} else if (temperatura.equals("calida")) {
			return "El pez esta en una temperatura adecuada ";
		} else {
			return "El pez no debe estar en agua " ;
		}
	}

	@Override
	public String respirar() {
		// TODO Auto-generated method stub
		return "Los peces respiran por las branqueas";
		
	}

	@Override
	public String ponerHuevos() {
		// TODO Auto-generated method stub
		return "El pez pone huevos en un nido";
	}
	
}
