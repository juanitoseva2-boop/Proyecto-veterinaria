package co.edu.unbosque.model;

import java.io.Serializable;

public class Producto implements Serializable {

	private static final long serialVersionUID = 4821907365514408213L;

	private String nombre;
	private String color;
	private float precio;
	private int tamano;

	public Producto() {
		
	}

	public Producto(String nombre, String color, float precio, int tamano) {
		super();
		this.nombre = nombre;
		this.color = color;
		this.precio = precio;
		this.tamano = tamano;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int getTamano() {
		return tamano;
	}

	public void setTamano(int tamano) {
		this.tamano = tamano;
	}

	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", color=" + color + ", precio=" + precio + ", tamano=" + tamano + "]";
	}
	
}
