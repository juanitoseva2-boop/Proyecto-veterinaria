 package co.edu.unbosque.model;

import java.io.Serializable;

public class Administrador  extends Persona implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5160219244308928181L;
	private String profesion;
	private String experiencia;
	
	public Administrador() {
		// TODO Auto-generated constructor stub
	}

	public Administrador(String profesion, String experiencia) {
		super();
		this.profesion = profesion;
		this.experiencia = experiencia;
	}

	public Administrador(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo,
			String profesion, String experiencia) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		this.profesion = profesion;
		this.experiencia = experiencia;
	}

	public Administrador(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		// TODO Auto-generated constructor stub
	}

	public String getProfesion() {
		return profesion;
	}

	public void setProfesion(String profesion) {
		this.profesion = profesion;
	}

	public String getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}

	@Override
	public String toString() {
		return super.toString() + " - Administrador [profesion=" + profesion + ", experiencia=" + experiencia + "]";
	}
	
	
	

}
