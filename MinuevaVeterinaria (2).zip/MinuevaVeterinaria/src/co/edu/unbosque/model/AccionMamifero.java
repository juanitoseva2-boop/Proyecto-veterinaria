package co.edu.unbosque.model;

public interface AccionMamifero {
	public String nacenSinHuevo();

}
