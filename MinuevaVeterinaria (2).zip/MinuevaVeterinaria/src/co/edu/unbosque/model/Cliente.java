package co.edu.unbosque.model;

import java.io.Serializable;

public class Cliente  extends Persona implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = -8530768886713781919L;
	private String nombreMascota;
	 private String tipoAnimal;
	 
	 public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nombreMascota, String tipoAnimal) {
		super();
		this.nombreMascota = nombreMascota;
		this.tipoAnimal = tipoAnimal;
	}

	public Cliente(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo,
			String nombreMascota, String tipoAnimal) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		this.nombreMascota = nombreMascota;
		this.tipoAnimal = tipoAnimal;
	}

	public Cliente(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		// TODO Auto-generated constructor stub
	}

	public String getNombreMascota() {
		return nombreMascota;
	}

	public void setNombreMascota(String nombreMascota) {
		this.nombreMascota = nombreMascota;
	}

	public String getTipoAnimal() {
		return tipoAnimal;
	}

	public void setTipoAnimal(String tipoAnimal) {
		this.tipoAnimal = tipoAnimal;
	}

	@Override
	public String toString() {
		return super.toString() + " - Cliente [nombreMascota=" + nombreMascota + ", tipoAnimal=" + tipoAnimal + "]";
	}
	 
}
