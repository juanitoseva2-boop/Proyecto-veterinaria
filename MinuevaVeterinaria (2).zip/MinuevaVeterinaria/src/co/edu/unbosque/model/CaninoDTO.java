package co.edu.unbosque.model;
public class CaninoDTO extends AnimalDTO  implements AccionNocturna,AccionMontana{
	private final String TIPO_SANGRE = "Caliente";
	private String tipoPelaje;
	private boolean esVacunado;

	public CaninoDTO() {
	}

	public CaninoDTO(String tipoPelaje, boolean esVacunado) {
		this.tipoPelaje = tipoPelaje;
		this.esVacunado = esVacunado;
	}

	public CaninoDTO(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super(nombre, edad, peso, esMacho, especie);
	}

	public CaninoDTO(String nombre, int edad, float peso, boolean esMacho, String especie, String tipoPelaje,
			boolean esVacunado) {
		super(nombre, edad, peso, esMacho, especie);
		this.tipoPelaje = tipoPelaje;
		this.esVacunado = esVacunado;
	}

	public String getTipoPelaje() {
		return tipoPelaje;
	}

	public void setTipoPelaje(String tipoPelaje) {
		this.tipoPelaje = tipoPelaje;
	}

	public boolean isEsVacunado() {
		return esVacunado;
	}

	public void setEsVacunado(boolean esVacunado) {
		this.esVacunado = esVacunado;
	}

	public String getTIPO_SANGRE() {
		return TIPO_SANGRE;
	}

	@Override
	public String toString() {
		return super.toString() + " - Canino [TIPO_SANGRE=" + TIPO_SANGRE + ", tipoPelaje=" + tipoPelaje + ", esVacunado=" + esVacunado + "]";
	}

	public String habitad(String lugar) {
		if (lugar.equals("bosque")) {
			return "Los caninos pueden habitar en bosques";
		} else if (lugar.equals("sabana")) {
			return "Los caninos pueden habitar en la sabana ";
		} else {
			return "Los caninos no pueden habitar en la sabana ";
		}
	}

	@Override
	public String dormir() {
		// TODO Auto-generated method stub
		return "Los caninos suelen dormir en una camita";
	}

	@Override
	public String escalar() {
		// TODO Auto-generated method stub
		return "Los caninos pueden escalar montañas,piedras,arboles";
	}

	@Override
	public String respirar() {
		// TODO Auto-generated method stub
		return "los caninos respiran por la boca ";
	}
}