package co.edu.unbosque.model;

import java.io.Serializable;

public class Medicamento extends Producto implements Serializable {

	private static final long serialVersionUID = -3947215580126738841L;
	private String fechaVencimiento;
	private String tipoMedicamento;
	private float numeroDosis;
	private float temperatura;

	public Medicamento() {
		// TODO Auto-generated constructor stub
	}

	public Medicamento(String fechaVencimiento, String tipoMedicamento, float numeroDosis, float temperatura) {
		super();
		this.fechaVencimiento = fechaVencimiento;
		this.tipoMedicamento = tipoMedicamento;
		this.numeroDosis = numeroDosis;
		this.temperatura = temperatura;
	}

	public Medicamento(String nombre, String color, float precio, int tamano, String fechaVencimiento,
			String tipoMedicamento, float numeroDosis, float temperatura) {
		super(nombre, color, precio, tamano);
		this.fechaVencimiento = fechaVencimiento;
		this.tipoMedicamento = tipoMedicamento;
		this.numeroDosis = numeroDosis;
		this.temperatura = temperatura;
	}

	public Medicamento(String nombre, String color, float precio, int tamano) {
		super(nombre, color, precio, tamano);
		// TODO Auto-generated constructor stub
	}

	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	public String getTipoMedicamento() {
		return tipoMedicamento;
	}

	public void setTipoMedicamento(String tipoMedicamento) {
		this.tipoMedicamento = tipoMedicamento;
	}

	public float getNumeroDosis() {
		return numeroDosis;
	}

	public void setNumeroDosis(float numeroDosis) {
		this.numeroDosis = numeroDosis;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

	@Override
	public String toString() {
		return super.toString() + " - Medicamento [fechaVencimiento=" + fechaVencimiento + ", tipoMedicamento=" + tipoMedicamento
				+ ", numeroDosis=" + numeroDosis + ", temperatura=" + temperatura + "]";
	}
	
}

	