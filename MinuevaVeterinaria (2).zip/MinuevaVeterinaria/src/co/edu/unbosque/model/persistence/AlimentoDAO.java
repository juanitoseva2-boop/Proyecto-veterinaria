package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Alimento;
import co.edu.unbosque.model.AlimentoDTO;

public class AlimentoDAO implements CRUDOperation<Alimento, AlimentoDTO> {

	private ArrayList<Alimento> listaAlimentos;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Alimentos.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Alimentos.csv";

	public AlimentoDAO() {
		// El ArrayList sigue siendo de Entidades
		listaAlimentos = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(AlimentoDTO nuevoDato) {
		listaAlimentos.add(DataMapper.convertirAlimentoDTOAAlimento(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAlimentos.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, AlimentoDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAlimentos.set(index, DataMapper.convertirAlimentoDTOAAlimento(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaAlimentos.isEmpty()) {
			return "No hay registros de alimento.";
		}
		String contenido = "";
		int posicion = 0;
		for (Alimento datoActual : listaAlimentos) {
			contenido += "\nAlimento #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Color: " + datoActual.getColor();
			contenido += "\n   Precio: " + datoActual.getPrecio();
			contenido += "\n   Tamano: " + datoActual.getTamano();
			contenido += "\n   Tipo de alimento: " + datoActual.getTipoAlimento();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es vegano: " + (datoActual.isEsVegano() ? "Si" : "No");
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaAlimentos.size();
	}

	public ArrayList<Alimento> getListaAlimentos() {
		return listaAlimentos;
	}

	public void setListaAlimentos(ArrayList<Alimento> listaAlimentos) {
		this.listaAlimentos = listaAlimentos;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Alimento alimento : listaAlimentos) {
			contenido += alimento.getNombre() + ";";
			contenido += alimento.getColor() + ";";
			contenido += alimento.getPrecio() + ";";
			contenido += alimento.getTamano() + ";";
			contenido += alimento.getTipoAlimento() + ";";
			contenido += alimento.getPeso() + ";";
			contenido += alimento.isEsVegano() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Alimento[] arreglo = new Alimento[listaAlimentos.size()];
		for (int i = 0; i < listaAlimentos.size(); i++) {
			arreglo[i] = listaAlimentos.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaAlimentos = new ArrayList<Alimento>();
		if (contenido != null) {
			Alimento[] arreglo = (Alimento[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaAlimentos.add(arreglo[i]);
			}
		}
	}

}
