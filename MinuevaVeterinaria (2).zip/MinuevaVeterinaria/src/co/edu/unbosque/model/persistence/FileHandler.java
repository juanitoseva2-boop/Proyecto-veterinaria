package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileHandler {
	private static File archivo;
	private static Scanner lector;
	private static PrintWriter escritor;

	public static FileOutputStream fos;

	public static ObjectOutputStream oos;

	public static FileInputStream fis;
	public static ObjectInputStream ois;

	public static void crearYEscribirArchivo(String url, String contenido) {

		try {
			archivo = new File(url);
			if (!archivo.exists()) {
				archivo.createNewFile();
			}
			escritor = new PrintWriter(archivo);
			escritor.println(contenido);
			escritor.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void crearYLeerArchivo(String url) {
		archivo = new File("files/" + url);

		try {
			if (!archivo.exists()) {
				archivo.getParentFile().mkdirs();
				archivo.createNewFile();
			}
			Scanner sc = new Scanner(archivo);
			while (sc.hasNext()) {
				sc.nextLine();
			}
			sc.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String abrirYLeerArchivo(String url) {
		String contenido = "";

		try {
			archivo = new File(url);
			if (!archivo.exists()) {
				archivo.createNewFile();
			}
			lector = new Scanner(archivo);
			while (lector.hasNext()) {
				contenido += lector.nextLine() + "\n";
			}
			lector.close();
			return contenido;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * Escribe el objeto (normalmente un ArrayList de entidades) en el archivo
	 * indicado por url.
	 */
	public static void crearYEscribirSerializado(String url, Object o) {
		try {
			archivo = new File(url);
			if (!archivo.exists()) {
				archivo.createNewFile();
			}
			fos = new FileOutputStream(archivo);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(o);
			oos.close();
			fos.close();
		} catch (IOException e) {
			System.out.println("Error al escribir el archivo serializado");
			e.printStackTrace();
		}
	}

	/**
	 * Lee el objeto serializado del archivo indicado por url. Si el archivo no
	 * existe, esta vacio o no se puede leer, devuelve null (el DAO se encarga de
	 * crear una lista nueva).
	 */
	public static Object abrirYleerSerializado(String url) {
		archivo = new File(url);
		if (!archivo.exists() || archivo.length() == 0) {
			return null;
		}
		try {
			fis = new FileInputStream(archivo);
			ois = new ObjectInputStream(fis);
			Object o = ois.readObject();
			ois.close();
			fis.close();
			return o;
		} catch (IOException e) {
			System.out.println("Error al abrir y leer el archivo serializado");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Error al comprender el contenido del archivo serializado");
			e.printStackTrace();
		}
		return null;
	}

	public static Object crearYleerArchivoSerializado(String url) {
		archivo = new File("files/" + url);
		try {
			if (!archivo.exists()) {
				archivo.getParentFile().mkdirs();
				archivo.createNewFile();
				return null;
			}
			if (archivo.length() == 0) {
				return null;
			}
			fis = new FileInputStream(archivo);
			ois = new ObjectInputStream(fis);
			Object contenido = ois.readObject();
			ois.close();
			fis.close();
			return contenido;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
