package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Pez;
import co.edu.unbosque.model.PezDTO;

public class PezDAO implements CRUDOperation<Pez, PezDTO> {

	private ArrayList<Pez> listaPeces;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Peces.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Peces.csv";

	public PezDAO() {
		// El ArrayList sigue siendo de Entidades
		listaPeces = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(PezDTO nuevoDato) {
		listaPeces.add(DataMapper.convertirPezDTOAPez(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaPeces.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, PezDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaPeces.set(index, DataMapper.convertirPezDTOAPez(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaPeces.isEmpty()) {
			return "No hay registros de pez.";
		}
		String contenido = "";
		int posicion = 0;
		for (Pez datoActual : listaPeces) {
			contenido += "\nPez #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Especie: " + datoActual.getEspecie();
			contenido += "\n   Edad: " + datoActual.getEdad();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es macho: " + (datoActual.isEsMacho() ? "Si" : "No");
			contenido += "\n   Tipo de sangre: " + datoActual.getTIPO_SANGRE();
			contenido += "\n   Es venenoso: " + (datoActual.isEsVenenoso() ? "Si" : "No");
			contenido += "\n   Consumo de alimento diario: " + datoActual.getConsumoAlimentoDiario();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaPeces.size();
	}

	public ArrayList<Pez> getListaPeces() {
		return listaPeces;
	}

	public void setListaPeces(ArrayList<Pez> listaPeces) {
		this.listaPeces = listaPeces;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Pez pez : listaPeces) {
			contenido += pez.getNombre() + ";";
			contenido += pez.getEspecie() + ";";
			contenido += pez.getEdad() + ";";
			contenido += pez.getPeso() + ";";
			contenido += pez.isEsMacho() + ";";
			contenido += pez.getTIPO_SANGRE() + ";";
			contenido += pez.isEsVenenoso() + ";";
			contenido += pez.getConsumoAlimentoDiario() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Pez[] arreglo = new Pez[listaPeces.size()];
		for (int i = 0; i < listaPeces.size(); i++) {
			arreglo[i] = listaPeces.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaPeces = new ArrayList<Pez>();
		if (contenido != null) {
			Pez[] arreglo = (Pez[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaPeces.add(arreglo[i]);
			}
		}
	}

}
