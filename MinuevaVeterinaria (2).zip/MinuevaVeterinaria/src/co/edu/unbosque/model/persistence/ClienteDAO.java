package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Cliente;
import co.edu.unbosque.model.ClienteDTO;

public class ClienteDAO implements CRUDOperation<Cliente, ClienteDTO> {

	private ArrayList<Cliente> listaClientes;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Clientes.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Clientes.csv";

	public ClienteDAO() {
		// El ArrayList sigue siendo de Entidades
		listaClientes = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(ClienteDTO nuevoDato) {
		listaClientes.add(DataMapper.convertirClienteDTOACliente(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaClientes.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, ClienteDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaClientes.set(index, DataMapper.convertirClienteDTOACliente(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaClientes.isEmpty()) {
			return "No hay registros de cliente.";
		}
		String contenido = "";
		int posicion = 0;
		for (Cliente datoActual : listaClientes) {
			contenido += "\nCliente #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Id: " + datoActual.getId();
			contenido += "\n   Correo electronico: " + datoActual.getCorreoElectronico();
			contenido += "\n   Numero de telefono: " + datoActual.getNumeroTelefono();
			contenido += "\n   Sexo: " + datoActual.getSexo();
			contenido += "\n   Nombre de la mascota: " + datoActual.getNombreMascota();
			contenido += "\n   Tipo de animal: " + datoActual.getTipoAnimal();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaClientes.size();
	}

	public ArrayList<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(ArrayList<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Cliente cliente : listaClientes) {
			contenido += cliente.getNombre() + ";";
			contenido += cliente.getId() + ";";
			contenido += cliente.getCorreoElectronico() + ";";
			contenido += cliente.getNumeroTelefono() + ";";
			contenido += cliente.getSexo() + ";";
			contenido += cliente.getNombreMascota() + ";";
			contenido += cliente.getTipoAnimal() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Cliente[] arreglo = new Cliente[listaClientes.size()];
		for (int i = 0; i < listaClientes.size(); i++) {
			arreglo[i] = listaClientes.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaClientes = new ArrayList<Cliente>();
		if (contenido != null) {
			Cliente[] arreglo = (Cliente[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaClientes.add(arreglo[i]);
			}
		}
	}

}
