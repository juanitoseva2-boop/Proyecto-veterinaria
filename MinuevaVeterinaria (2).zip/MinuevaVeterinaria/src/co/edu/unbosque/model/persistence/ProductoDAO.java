package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Producto;
import co.edu.unbosque.model.ProductoDTO;

public class ProductoDAO implements CRUDOperation<Producto, ProductoDTO> {

	private ArrayList<Producto> listaProductos;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Productos.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Productos.csv";

	public ProductoDAO() {
		// El ArrayList sigue siendo de Entidades
		listaProductos = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(ProductoDTO nuevoDato) {
		listaProductos.add(DataMapper.convertirProductoDTOAProducto(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaProductos.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, ProductoDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaProductos.set(index, DataMapper.convertirProductoDTOAProducto(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaProductos.isEmpty()) {
			return "No hay registros de producto.";
		}
		String contenido = "";
		int posicion = 0;
		for (Producto datoActual : listaProductos) {
			contenido += "\nProducto #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Color: " + datoActual.getColor();
			contenido += "\n   Precio: " + datoActual.getPrecio();
			contenido += "\n   Tamano: " + datoActual.getTamano();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaProductos.size();
	}

	public ArrayList<Producto> getListaProductos() {
		return listaProductos;
	}

	public void setListaProductos(ArrayList<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Producto producto : listaProductos) {
			contenido += producto.getNombre() + ";";
			contenido += producto.getColor() + ";";
			contenido += producto.getPrecio() + ";";
			contenido += producto.getTamano() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Producto[] arreglo = new Producto[listaProductos.size()];
		for (int i = 0; i < listaProductos.size(); i++) {
			arreglo[i] = listaProductos.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaProductos = new ArrayList<Producto>();
		if (contenido != null) {
			Producto[] arreglo = (Producto[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaProductos.add(arreglo[i]);
			}
		}
	}

}
