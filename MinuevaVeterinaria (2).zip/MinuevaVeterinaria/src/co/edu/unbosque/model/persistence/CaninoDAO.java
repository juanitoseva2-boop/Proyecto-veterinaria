package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Canino;
import co.edu.unbosque.model.CaninoDTO;

public class CaninoDAO implements CRUDOperation<Canino, CaninoDTO> {

	private ArrayList<Canino> listaCaninos;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Caninos.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Caninos.csv";

	public CaninoDAO() {
		// El ArrayList sigue siendo de Entidades
		listaCaninos = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(CaninoDTO nuevoDato) {
		listaCaninos.add(DataMapper.convertirCaninoDTOACanino(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaCaninos.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, CaninoDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaCaninos.set(index, DataMapper.convertirCaninoDTOACanino(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaCaninos.isEmpty()) {
			return "No hay registros de canino.";
		}
		String contenido = "";
		int posicion = 0;
		for (Canino datoActual : listaCaninos) {
			contenido += "\nCanino #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Especie: " + datoActual.getEspecie();
			contenido += "\n   Edad: " + datoActual.getEdad();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es macho: " + (datoActual.isEsMacho() ? "Si" : "No");
			contenido += "\n   Tipo de sangre: " + datoActual.getTIPO_SANGRE();
			contenido += "\n   Tipo de pelaje: " + datoActual.getTipoPelaje();
			contenido += "\n   Esta vacunado: " + (datoActual.isEsVacunado() ? "Si" : "No");
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaCaninos.size();
	}

	public ArrayList<Canino> getListaCaninos() {
		return listaCaninos;
	}

	public void setListaCaninos(ArrayList<Canino> listaCaninos) {
		this.listaCaninos = listaCaninos;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Canino canino : listaCaninos) {
			contenido += canino.getNombre() + ";";
			contenido += canino.getEspecie() + ";";
			contenido += canino.getEdad() + ";";
			contenido += canino.getPeso() + ";";
			contenido += canino.isEsMacho() + ";";
			contenido += canino.getTIPO_SANGRE() + ";";
			contenido += canino.getTipoPelaje() + ";";
			contenido += canino.isEsVacunado() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Canino[] arreglo = new Canino[listaCaninos.size()];
		for (int i = 0; i < listaCaninos.size(); i++) {
			arreglo[i] = listaCaninos.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaCaninos = new ArrayList<Canino>();
		if (contenido != null) {
			Canino[] arreglo = (Canino[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaCaninos.add(arreglo[i]);
			}
		}
	}

}
