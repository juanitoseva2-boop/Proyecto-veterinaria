package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.PersonaDTO;

public class PersonaDAO implements CRUDOperation<Persona, PersonaDTO> {

	private ArrayList<Persona> listaPersonas;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Personas.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Personas.csv";

	public PersonaDAO() {
		// El ArrayList sigue siendo de Entidades
		listaPersonas = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(PersonaDTO nuevoDato) {
		listaPersonas.add(DataMapper.convertirPersonaDTOAPersona(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaPersonas.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, PersonaDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaPersonas.set(index, DataMapper.convertirPersonaDTOAPersona(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaPersonas.isEmpty()) {
			return "No hay registros de persona.";
		}
		String contenido = "";
		int posicion = 0;
		for (Persona datoActual : listaPersonas) {
			contenido += "\nPersona #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Id: " + datoActual.getId();
			contenido += "\n   Correo electronico: " + datoActual.getCorreoElectronico();
			contenido += "\n   Numero de telefono: " + datoActual.getNumeroTelefono();
			contenido += "\n   Sexo: " + datoActual.getSexo();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaPersonas.size();
	}

	public ArrayList<Persona> getListaPersonas() {
		return listaPersonas;
	}

	public void setListaPersonas(ArrayList<Persona> listaPersonas) {
		this.listaPersonas = listaPersonas;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Persona persona : listaPersonas) {
			contenido += persona.getNombre() + ";";
			contenido += persona.getId() + ";";
			contenido += persona.getCorreoElectronico() + ";";
			contenido += persona.getNumeroTelefono() + ";";
			contenido += persona.getSexo() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Persona[] arreglo = new Persona[listaPersonas.size()];
		for (int i = 0; i < listaPersonas.size(); i++) {
			arreglo[i] = listaPersonas.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaPersonas = new ArrayList<Persona>();
		if (contenido != null) {
			Persona[] arreglo = (Persona[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaPersonas.add(arreglo[i]);
			}
		}
	}

}
