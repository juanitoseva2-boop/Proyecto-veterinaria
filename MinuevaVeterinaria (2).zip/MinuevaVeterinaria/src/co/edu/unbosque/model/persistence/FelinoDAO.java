package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Felino;
import co.edu.unbosque.model.FelinoDTO;

public class FelinoDAO implements CRUDOperation<Felino, FelinoDTO> {

	private ArrayList<Felino> listaFelinos;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Felinos.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Felinos.csv";

	public FelinoDAO() {
		// El ArrayList sigue siendo de Entidades
		listaFelinos = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(FelinoDTO nuevoDato) {
		listaFelinos.add(DataMapper.convertirFelinoDTOAFelino(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaFelinos.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, FelinoDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaFelinos.set(index, DataMapper.convertirFelinoDTOAFelino(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaFelinos.isEmpty()) {
			return "No hay registros de felino.";
		}
		String contenido = "";
		int posicion = 0;
		for (Felino datoActual : listaFelinos) {
			contenido += "\nFelino #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Especie: " + datoActual.getEspecie();
			contenido += "\n   Edad: " + datoActual.getEdad();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es macho: " + (datoActual.isEsMacho() ? "Si" : "No");
			contenido += "\n   Tipo de sangre: " + datoActual.getTIPO_SANGRE();
			contenido += "\n   Color del pelaje: " + datoActual.getColorPelaje();
			contenido += "\n   Es domestico: " + (datoActual.isEsDomestico() ? "Si" : "No");
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaFelinos.size();
	}

	public ArrayList<Felino> getListaFelinos() {
		return listaFelinos;
	}

	public void setListaFelinos(ArrayList<Felino> listaFelinos) {
		this.listaFelinos = listaFelinos;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Felino felino : listaFelinos) {
			contenido += felino.getNombre() + ";";
			contenido += felino.getEspecie() + ";";
			contenido += felino.getEdad() + ";";
			contenido += felino.getPeso() + ";";
			contenido += felino.isEsMacho() + ";";
			contenido += felino.getTIPO_SANGRE() + ";";
			contenido += felino.getColorPelaje() + ";";
			contenido += felino.isEsDomestico() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Felino[] arreglo = new Felino[listaFelinos.size()];
		for (int i = 0; i < listaFelinos.size(); i++) {
			arreglo[i] = listaFelinos.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaFelinos = new ArrayList<Felino>();
		if (contenido != null) {
			Felino[] arreglo = (Felino[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaFelinos.add(arreglo[i]);
			}
		}
	}

}
