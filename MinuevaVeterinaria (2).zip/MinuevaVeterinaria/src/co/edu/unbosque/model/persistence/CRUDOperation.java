package co.edu.unbosque.model.persistence;

public interface CRUDOperation <E,D> {
	
	public void crear (D nuevoDato);
	
	public boolean eliminar(int index);
	
	public boolean actualizar(int index,D datoActualizado);
	
	public String mostrarTodo();
	
	
	public int contar();
	
}
