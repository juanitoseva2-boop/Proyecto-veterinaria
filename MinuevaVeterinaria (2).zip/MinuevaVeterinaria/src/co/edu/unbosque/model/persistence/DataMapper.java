package co.edu.unbosque.model.persistence;

import co.edu.unbosque.model.Accesorio;
import co.edu.unbosque.model.AccesorioDTO;
import co.edu.unbosque.model.Administrador;
import co.edu.unbosque.model.AdministradorDTO;
import co.edu.unbosque.model.Alimento;
import co.edu.unbosque.model.AlimentoDTO;
import co.edu.unbosque.model.Ave;
import co.edu.unbosque.model.AveDTO;
import co.edu.unbosque.model.Canino;
import co.edu.unbosque.model.CaninoDTO;
import co.edu.unbosque.model.Cliente;
import co.edu.unbosque.model.ClienteDTO;
import co.edu.unbosque.model.Felino;
import co.edu.unbosque.model.FelinoDTO;
import co.edu.unbosque.model.Medicamento;
import co.edu.unbosque.model.MedicamentoDTO;
import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.PersonaDTO;
import co.edu.unbosque.model.Pez;
import co.edu.unbosque.model.PezDTO;
import co.edu.unbosque.model.Producto;
import co.edu.unbosque.model.ProductoDTO;
import co.edu.unbosque.model.Reptil;
import co.edu.unbosque.model.ReptilDTO;
import co.edu.unbosque.model.Veterinario;
import co.edu.unbosque.model.VeterinarioDTO;

public class DataMapper {
	public static Reptil convertirReptilDTOAReptil(ReptilDTO dto) {
		Reptil entity = new Reptil();

		entity.setNombre(dto.getNombre());
		entity.setEdad(dto.getEdad());
		entity.setEspecie(dto.getEspecie());
		entity.setEsMacho(dto.isEsMacho());
		entity.setPeso(dto.getPeso());
		entity.setEsVenenoso(dto.isEsVenenoso());
		entity.setTipoEscama(dto.getTipoEscama());
		return entity;

	}

	public static ReptilDTO convertirReptilAReptilDTO(Reptil entity) {
		ReptilDTO dto = new ReptilDTO();

		dto.setNombre(entity.getNombre());
		dto.setEdad(entity.getEdad());
		dto.setEspecie(entity.getEspecie());
		dto.setEsMacho(entity.isEsMacho());
		dto.setPeso(entity.getPeso());
		dto.setEsVenenoso(entity.isEsVenenoso());
		dto.setTipoEscama(entity.getTipoEscama());
		return dto;

	}

	public static Felino convertirFelinoDTOAFelino(FelinoDTO dto) {
		Felino entity = new Felino();
		entity.setNombre(dto.getNombre());
		entity.setEdad(dto.getEdad());
		entity.setEspecie(dto.getEspecie());
		entity.setEsMacho(dto.isEsMacho());
		entity.setPeso(dto.getPeso());
		entity.setEsDomestico(dto.isEsDomestico());
		entity.setColorPelaje(dto.getColorPelaje());
		return entity;
	}

	public static FelinoDTO convertirFelinoAFelinoDTO(Felino entity) {
		FelinoDTO dto = new FelinoDTO();
		dto.setNombre(entity.getNombre());
		dto.setEdad(entity.getEdad());
		dto.setEspecie(entity.getEspecie());
		dto.setEsMacho(entity.isEsMacho());
		dto.setPeso(entity.getPeso());
		dto.setEsDomestico(entity.isEsDomestico());
		dto.setColorPelaje(entity.getColorPelaje());
		return dto;
	}

	public static Canino convertirCaninoDTOACanino(CaninoDTO dto) {
		Canino entity = new Canino();
		entity.setNombre(dto.getNombre());
		entity.setEdad(dto.getEdad());
		entity.setEspecie(dto.getEspecie());
		entity.setEsMacho(dto.isEsMacho());
		entity.setPeso(dto.getPeso());
		entity.setEsVacunado(dto.isEsVacunado());
		entity.setTipoPelaje(dto.getTipoPelaje());
		return entity;
	}

	public static CaninoDTO convertirCaninoACaninoDTO(Canino entity) {
		CaninoDTO dto = new CaninoDTO();

		dto.setNombre(entity.getNombre());
		dto.setEdad(entity.getEdad());
		dto.setEspecie(entity.getEspecie());
		dto.setEsMacho(entity.isEsMacho());
		dto.setPeso(entity.getPeso());
		dto.setEsVacunado(entity.isEsVacunado());
		dto.setTipoPelaje(entity.getTipoPelaje());
		return dto;
	}

	public static Pez convertirPezDTOAPez(PezDTO dto) {
		Pez entity = new Pez();
		entity.setNombre(dto.getNombre());
		entity.setEdad(dto.getEdad());
		entity.setEspecie(dto.getEspecie());
		entity.setEsMacho(dto.isEsMacho());
		entity.setPeso(dto.getPeso());
		entity.setEsVenenoso(dto.isEsVenenoso());
		entity.setConsumoAlimentoDiario(dto.getConsumoAlimentoDiario());
		return entity;
	}

	public static PezDTO convertirPezAPezDTO(Pez entity) {

		PezDTO dto = new PezDTO();

		dto.setNombre(entity.getNombre());
		dto.setEdad(entity.getEdad());
		dto.setEspecie(entity.getEspecie());
		dto.setEsMacho(entity.isEsMacho());
		dto.setPeso(entity.getPeso());
		dto.setEsVenenoso(entity.isEsVenenoso());
		dto.setConsumoAlimentoDiario(entity.getConsumoAlimentoDiario());
		return dto;
	}

	public static Ave convertirAveDTOAAve(AveDTO dto) {
		Ave entity = new Ave();
		entity.setNombre(dto.getNombre());
		entity.setEdad(dto.getEdad());
		entity.setEspecie(dto.getEspecie());
		entity.setEsMacho(dto.isEsMacho());
		entity.setPeso(dto.getPeso());
		entity.setTipoPico(dto.getTipoPico());
		entity.setPuedeReproducirse(dto.isPuedeReproducirse());
		return entity;

	}

	public static AveDTO convertirAveAAveDTO(Ave entity) {

		AveDTO dto = new AveDTO();

		dto.setNombre(entity.getNombre());
		dto.setEdad(entity.getEdad());
		dto.setEspecie(entity.getEspecie());
		dto.setEsMacho(entity.isEsMacho());
		dto.setPeso(entity.getPeso());
		dto.setTipoPico(entity.getTipoPico());
		dto.setPuedeReproducirse(entity.isPuedeReproducirse());
		return dto;
	}

	public static Cliente convertirClienteDTOACliente(ClienteDTO dto) {
		Cliente entity = new Cliente();
		entity.setNombre(dto.getNombre());
		entity.setCorreoElectronico(dto.getCorreoElectronico());
		entity.setId(dto.getId());
		entity.setNumeroTelefono(dto.getNumeroTelefono());
		entity.setSexo(dto.getSexo());
		entity.setNombreMascota(dto.getNombreMascota());
		entity.setTipoAnimal(dto.getTipoAnimal());
		return entity;
	}

	public static ClienteDTO convertirClienteAClienteDTO(Cliente entity) {
		ClienteDTO dto = new ClienteDTO();
		dto.setNombre(entity.getNombre());
		dto.setCorreoElectronico(entity.getCorreoElectronico());
		dto.setId(entity.getId());
		dto.setNumeroTelefono(entity.getNumeroTelefono());
		dto.setSexo(entity.getSexo());
		dto.setNombreMascota(entity.getNombreMascota());
		dto.setTipoAnimal(entity.getTipoAnimal());
		return dto;

	}

	public static Veterinario convertirVeterinarioDTOAVeterinario(VeterinarioDTO dto) {
		Veterinario entity = new Veterinario();
		entity.setNombre(dto.getNombre());
		entity.setCorreoElectronico(dto.getCorreoElectronico());
		entity.setId(dto.getId());
		entity.setNumeroTelefono(dto.getNumeroTelefono());
		entity.setSexo(dto.getSexo());
		entity.setEspecialidad(dto.getEspecialidad());
		entity.setExperiencia(dto.getExperiencia());
		entity.setTipoContrato(dto.getTipoContrato());
		return entity;
	}

	public static VeterinarioDTO convertirVeterinarioAVeterinarioDTO(Veterinario entity) {
		VeterinarioDTO dto = new VeterinarioDTO();
		dto.setNombre(entity.getNombre());
		dto.setCorreoElectronico(entity.getCorreoElectronico());
		dto.setId(entity.getId());
		dto.setNumeroTelefono(entity.getNumeroTelefono());
		dto.setSexo(entity.getSexo());
		dto.setEspecialidad(entity.getEspecialidad());
		dto.setExperiencia(entity.getExperiencia());
		dto.setTipoContrato(entity.getTipoContrato());
		return dto;
	}

	public static Administrador convertirAdministradorDTOAAdministrador(AdministradorDTO dto) {
		Administrador entity = new Administrador();
		entity.setNombre(dto.getNombre());
		entity.setCorreoElectronico(dto.getCorreoElectronico());
		entity.setId(dto.getId());
		entity.setNumeroTelefono(dto.getNumeroTelefono());
		entity.setSexo(dto.getSexo());
		entity.setExperiencia(dto.getExperiencia());
		entity.setProfesion(dto.getProfesion());
		return entity;
	}

	public static AdministradorDTO convertirAdministradorAAdministradorDTO(Administrador entity) {
		AdministradorDTO dto = new AdministradorDTO();
		dto.setNombre(entity.getNombre());
		dto.setCorreoElectronico(entity.getCorreoElectronico());
		dto.setId(entity.getId());
		dto.setNumeroTelefono(entity.getNumeroTelefono());
		dto.setSexo(entity.getSexo());
		dto.setExperiencia(entity.getExperiencia());
		dto.setProfesion(entity.getProfesion());

		return dto;

	}

	public static Medicamento convertirMedicamentoDTOAMedicamento(MedicamentoDTO dto) {
		Medicamento entity = new Medicamento();
		entity.setNombre(dto.getNombre());
		entity.setColor(dto.getColor());
		entity.setFechaVencimiento(dto.getFechaVencimiento());
		entity.setNumeroDosis(dto.getNumeroDosis());
		entity.setPrecio(dto.getPrecio());
		entity.setTamano(dto.getTamano());
		entity.setTemperatura(dto.getTemperatura());
		entity.setTipoMedicamento(dto.getTipoMedicamento());
		return entity;
	}

	public static MedicamentoDTO convertirMedicamentoAMedicamentoDTO(Medicamento entity) {
		MedicamentoDTO dto = new MedicamentoDTO();
		dto.setNombre(entity.getNombre());
		dto.setColor(entity.getColor());
		dto.setFechaVencimiento(entity.getFechaVencimiento());
		dto.setNumeroDosis(entity.getNumeroDosis());
		dto.setPrecio(entity.getPrecio());
		dto.setTamano(entity.getTamano());
		dto.setTemperatura(entity.getTemperatura());
		dto.setTipoMedicamento(entity.getTipoMedicamento());
		return dto;

	}

	public static Alimento convertirAlimentoDTOAAlimento(AlimentoDTO dto) {
		Alimento entity = new Alimento();
		entity.setNombre(dto.getNombre());
		entity.setColor(dto.getColor());
		entity.setPeso(dto.getPeso());
		entity.setPrecio(dto.getPrecio());
		entity.setTamano(dto.getTamano());
		entity.setEsVegano(dto.isEsVegano());
		entity.setTipoAlimento(dto.getTipoAlimento());
		return entity;

	}

	public static AlimentoDTO convertirAlimentoAAlimentoDTO(Alimento entity) {
		AlimentoDTO dto = new AlimentoDTO();
		dto.setNombre(entity.getNombre());
		dto.setColor(entity.getColor());
		dto.setPeso(entity.getPeso());
		dto.setPrecio(entity.getPrecio());
		dto.setTamano(entity.getTamano());
		dto.setEsVegano(entity.isEsVegano());
		dto.setTipoAlimento(entity.getTipoAlimento());

		return dto;
	}

	public static Accesorio convertirAccesorioDTOAAccesorio(AccesorioDTO dto) {
		Accesorio entity = new Accesorio();
		entity.setNombre(dto.getNombre());
		entity.setColor(dto.getColor());
		entity.setPrecio(dto.getPrecio());
		entity.setTalla(dto.getTalla());
		entity.setTamano(dto.getTamano());
		entity.setParteCuerpo(dto.getParteCuerpo());
		entity.setTipoAccesorio(dto.getTipoAccesorio());
		return entity;

	}

	public static AccesorioDTO convertirAccesorioAAccesorioDTO(Accesorio entity) {
		AccesorioDTO dto = new AccesorioDTO();
		dto.setNombre(entity.getNombre());
		dto.setColor(entity.getColor());
		dto.setPrecio(entity.getPrecio());
		dto.setTalla(entity.getTalla());
		dto.setTamano(entity.getTamano());
		dto.setParteCuerpo(entity.getParteCuerpo());
		dto.setTipoAccesorio(entity.getTipoAccesorio());
		return dto;
	}

	public static Persona convertirPersonaDTOAPersona(PersonaDTO dto) {
		Persona entity = new Persona();
		entity.setNombre(dto.getNombre());
		entity.setCorreoElectronico(dto.getCorreoElectronico());
		entity.setId(dto.getId());
		entity.setNumeroTelefono(dto.getNumeroTelefono());
		entity.setSexo(dto.getSexo());
		return entity;
	}

	public static PersonaDTO convertirPersonaAPersonaDTO(Persona entity) {
		PersonaDTO dto = new PersonaDTO();
		dto.setNombre(entity.getNombre());
		dto.setCorreoElectronico(entity.getCorreoElectronico());
		dto.setId(entity.getId());
		dto.setNumeroTelefono(entity.getNumeroTelefono());
		dto.setSexo(entity.getSexo());
		return dto;

	}
	public static Producto convertirProductoDTOAProducto(ProductoDTO dto) {
		Producto entity = new Producto();
		entity.setNombre(dto.getNombre());
		entity.setColor(dto.getColor());
		entity.setPrecio(dto.getPrecio());
		entity.setTamano(dto.getTamano());
		return entity;
	}
	public static ProductoDTO convertirProductoAProductoDTO(Producto entity) {
		ProductoDTO dto = new ProductoDTO();
		dto.setNombre(entity.getNombre());
		dto.setColor(entity.getColor());
		dto.setPrecio(entity.getPrecio());
		dto.setTamano(entity.getTamano());
		return dto;
	}
}