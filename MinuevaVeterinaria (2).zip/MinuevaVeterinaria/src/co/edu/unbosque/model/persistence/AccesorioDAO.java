package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Accesorio;
import co.edu.unbosque.model.AccesorioDTO;

public class AccesorioDAO implements CRUDOperation<Accesorio, AccesorioDTO> {

	private ArrayList<Accesorio> listaAccesorios;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Accesorios.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Accesorios.csv";

	public AccesorioDAO() {
		// El ArrayList sigue siendo de Entidades
		listaAccesorios = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(AccesorioDTO nuevoDato) {
		listaAccesorios.add(DataMapper.convertirAccesorioDTOAAccesorio(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAccesorios.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, AccesorioDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAccesorios.set(index, DataMapper.convertirAccesorioDTOAAccesorio(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaAccesorios.isEmpty()) {
			return "No hay registros de accesorio.";
		}
		String contenido = "";
		int posicion = 0;
		for (Accesorio datoActual : listaAccesorios) {
			contenido += "\nAccesorio #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Color: " + datoActual.getColor();
			contenido += "\n   Precio: " + datoActual.getPrecio();
			contenido += "\n   Tamano: " + datoActual.getTamano();
			contenido += "\n   Tipo de accesorio: " + datoActual.getTipoAccesorio();
			contenido += "\n   Talla: " + datoActual.getTalla();
			contenido += "\n   Parte del cuerpo: " + datoActual.getParteCuerpo();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaAccesorios.size();
	}

	public ArrayList<Accesorio> getListaAccesorios() {
		return listaAccesorios;
	}

	public void setListaAccesorios(ArrayList<Accesorio> listaAccesorios) {
		this.listaAccesorios = listaAccesorios;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Accesorio accesorio : listaAccesorios) {
			contenido += accesorio.getNombre() + ";";
			contenido += accesorio.getColor() + ";";
			contenido += accesorio.getPrecio() + ";";
			contenido += accesorio.getTamano() + ";";
			contenido += accesorio.getTipoAccesorio() + ";";
			contenido += accesorio.getTalla() + ";";
			contenido += accesorio.getParteCuerpo() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Accesorio[] arreglo = new Accesorio[listaAccesorios.size()];
		for (int i = 0; i < listaAccesorios.size(); i++) {
			arreglo[i] = listaAccesorios.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaAccesorios = new ArrayList<Accesorio>();
		if (contenido != null) {
			Accesorio[] arreglo = (Accesorio[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaAccesorios.add(arreglo[i]);
			}
		}
	}

}
