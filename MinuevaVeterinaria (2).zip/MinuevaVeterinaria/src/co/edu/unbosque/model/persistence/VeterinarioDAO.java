package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Veterinario;
import co.edu.unbosque.model.VeterinarioDTO;

public class VeterinarioDAO implements CRUDOperation<Veterinario, VeterinarioDTO> {

	private ArrayList<Veterinario> listaVeterinarios;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Veterinarios.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Veterinarios.csv";

	public VeterinarioDAO() {
		// El ArrayList sigue siendo de Entidades
		listaVeterinarios = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(VeterinarioDTO nuevoDato) {
		listaVeterinarios.add(DataMapper.convertirVeterinarioDTOAVeterinario(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaVeterinarios.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, VeterinarioDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaVeterinarios.set(index, DataMapper.convertirVeterinarioDTOAVeterinario(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaVeterinarios.isEmpty()) {
			return "No hay registros de veterinario.";
		}
		String contenido = "";
		int posicion = 0;
		for (Veterinario datoActual : listaVeterinarios) {
			contenido += "\nVeterinario #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Id: " + datoActual.getId();
			contenido += "\n   Correo electronico: " + datoActual.getCorreoElectronico();
			contenido += "\n   Numero de telefono: " + datoActual.getNumeroTelefono();
			contenido += "\n   Especialidad: " + datoActual.getEspecialidad();
			contenido += "\n   Experiencia: " + datoActual.getExperiencia();
			contenido += "\n   Tipo de contrato: " + datoActual.getTipoContrato();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaVeterinarios.size();
	}

	public ArrayList<Veterinario> getListaVeterinarios() {
		return listaVeterinarios;
	}

	public void setListaVeterinarios(ArrayList<Veterinario> listaVeterinarios) {
		this.listaVeterinarios = listaVeterinarios;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Veterinario veterinario : listaVeterinarios) {
			contenido += veterinario.getNombre() + ";";
			contenido += veterinario.getId() + ";";
			contenido += veterinario.getCorreoElectronico() + ";";
			contenido += veterinario.getNumeroTelefono() + ";";
			contenido += veterinario.getEspecialidad() + ";";
			contenido += veterinario.getExperiencia() + ";";
			contenido += veterinario.getTipoContrato() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Veterinario[] arreglo = new Veterinario[listaVeterinarios.size()];
		for (int i = 0; i < listaVeterinarios.size(); i++) {
			arreglo[i] = listaVeterinarios.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaVeterinarios = new ArrayList<Veterinario>();
		if (contenido != null) {
			Veterinario[] arreglo = (Veterinario[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaVeterinarios.add(arreglo[i]);
			}
		}
	}

}
