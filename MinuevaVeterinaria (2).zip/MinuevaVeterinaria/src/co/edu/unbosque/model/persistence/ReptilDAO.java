package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Reptil;
import co.edu.unbosque.model.ReptilDTO;

public class ReptilDAO implements CRUDOperation<Reptil, ReptilDTO> {

	private ArrayList<Reptil> listaReptiles;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Reptiles.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Reptiles.csv";

	public ReptilDAO() {
		// El ArrayList sigue siendo de Entidades
		listaReptiles = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(ReptilDTO nuevoDato) {
		listaReptiles.add(DataMapper.convertirReptilDTOAReptil(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaReptiles.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, ReptilDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaReptiles.set(index, DataMapper.convertirReptilDTOAReptil(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaReptiles.isEmpty()) {
			return "No hay registros de reptil.";
		}
		String contenido = "";
		int posicion = 0;
		for (Reptil datoActual : listaReptiles) {
			contenido += "\nReptil #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Especie: " + datoActual.getEspecie();
			contenido += "\n   Edad: " + datoActual.getEdad();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es macho: " + (datoActual.isEsMacho() ? "Si" : "No");
			contenido += "\n   Tipo de sangre: " + datoActual.getTIPO_SANGRE();
			contenido += "\n   Tipo de escama: " + datoActual.getTipoEscama();
			contenido += "\n   Es venenoso: " + (datoActual.isEsVenenoso() ? "Si" : "No");
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaReptiles.size();
	}

	public ArrayList<Reptil> getListaReptiles() {
		return listaReptiles;
	}

	public void setListaReptiles(ArrayList<Reptil> listaReptiles) {
		this.listaReptiles = listaReptiles;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Reptil reptil : listaReptiles) {
			contenido += reptil.getNombre() + ";";
			contenido += reptil.getEspecie() + ";";
			contenido += reptil.getEdad() + ";";
			contenido += reptil.getPeso() + ";";
			contenido += reptil.isEsMacho() + ";";
			contenido += reptil.getTIPO_SANGRE() + ";";
			contenido += reptil.getTipoEscama() + ";";
			contenido += reptil.isEsVenenoso() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Reptil[] arreglo = new Reptil[listaReptiles.size()];
		for (int i = 0; i < listaReptiles.size(); i++) {
			arreglo[i] = listaReptiles.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaReptiles = new ArrayList<Reptil>();
		if (contenido != null) {
			Reptil[] arreglo = (Reptil[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaReptiles.add(arreglo[i]);
			}
		}
	}

}
