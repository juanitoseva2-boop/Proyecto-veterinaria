package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Medicamento;
import co.edu.unbosque.model.MedicamentoDTO;

public class MedicamentoDAO implements CRUDOperation<Medicamento, MedicamentoDTO> {

	private ArrayList<Medicamento> listaMedicamentos;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Medicamentos.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Medicamentos.csv";

	public MedicamentoDAO() {
		// El ArrayList sigue siendo de Entidades
		listaMedicamentos = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(MedicamentoDTO nuevoDato) {
		listaMedicamentos.add(DataMapper.convertirMedicamentoDTOAMedicamento(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaMedicamentos.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, MedicamentoDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaMedicamentos.set(index, DataMapper.convertirMedicamentoDTOAMedicamento(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaMedicamentos.isEmpty()) {
			return "No hay registros de medicamento.";
		}
		String contenido = "";
		int posicion = 0;
		for (Medicamento datoActual : listaMedicamentos) {
			contenido += "\nMedicamento #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Color: " + datoActual.getColor();
			contenido += "\n   Precio: " + datoActual.getPrecio();
			contenido += "\n   Tamano: " + datoActual.getTamano();
			contenido += "\n   Fecha de vencimiento: " + datoActual.getFechaVencimiento();
			contenido += "\n   Tipo de medicamento: " + datoActual.getTipoMedicamento();
			contenido += "\n   Numero de dosis: " + datoActual.getNumeroDosis();
			contenido += "\n   Temperatura: " + datoActual.getTemperatura();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaMedicamentos.size();
	}

	public ArrayList<Medicamento> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(ArrayList<Medicamento> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Medicamento medicamento : listaMedicamentos) {
			contenido += medicamento.getNombre() + ";";
			contenido += medicamento.getColor() + ";";
			contenido += medicamento.getPrecio() + ";";
			contenido += medicamento.getTamano() + ";";
			contenido += medicamento.getFechaVencimiento() + ";";
			contenido += medicamento.getTipoMedicamento() + ";";
			contenido += medicamento.getNumeroDosis() + ";";
			contenido += medicamento.getTemperatura() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Medicamento[] arreglo = new Medicamento[listaMedicamentos.size()];
		for (int i = 0; i < listaMedicamentos.size(); i++) {
			arreglo[i] = listaMedicamentos.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaMedicamentos = new ArrayList<Medicamento>();
		if (contenido != null) {
			Medicamento[] arreglo = (Medicamento[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaMedicamentos.add(arreglo[i]);
			}
		}
	}

}
