package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Administrador;
import co.edu.unbosque.model.AdministradorDTO;

public class AdministradorDAO implements CRUDOperation<Administrador, AdministradorDTO> {

	private ArrayList<Administrador> listaAdministradores;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Administradores.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Administradores.csv";

	public AdministradorDAO() {
		// El ArrayList sigue siendo de Entidades
		listaAdministradores = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(AdministradorDTO nuevoDato) {
		listaAdministradores.add(DataMapper.convertirAdministradorDTOAAdministrador(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAdministradores.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, AdministradorDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAdministradores.set(index, DataMapper.convertirAdministradorDTOAAdministrador(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaAdministradores.isEmpty()) {
			return "No hay registros de administrador.";
		}
		String contenido = "";
		int posicion = 0;
		for (Administrador datoActual : listaAdministradores) {
			contenido += "\nAdministrador #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Id: " + datoActual.getId();
			contenido += "\n   Correo electronico: " + datoActual.getCorreoElectronico();
			contenido += "\n   Numero de telefono: " + datoActual.getNumeroTelefono();
			contenido += "\n   Sexo: " + datoActual.getSexo();
			contenido += "\n   Profesion: " + datoActual.getProfesion();
			contenido += "\n   Experiencia: " + datoActual.getExperiencia();
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaAdministradores.size();
	}

	public ArrayList<Administrador> getListaAdministradores() {
		return listaAdministradores;
	}

	public void setListaAdministradores(ArrayList<Administrador> listaAdministradores) {
		this.listaAdministradores = listaAdministradores;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Administrador administrador : listaAdministradores) {
			contenido += administrador.getNombre() + ";";
			contenido += administrador.getId() + ";";
			contenido += administrador.getCorreoElectronico() + ";";
			contenido += administrador.getNumeroTelefono() + ";";
			contenido += administrador.getSexo() + ";";
			contenido += administrador.getProfesion() + ";";
			contenido += administrador.getExperiencia() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Administrador[] arreglo = new Administrador[listaAdministradores.size()];
		for (int i = 0; i < listaAdministradores.size(); i++) {
			arreglo[i] = listaAdministradores.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaAdministradores = new ArrayList<Administrador>();
		if (contenido != null) {
			Administrador[] arreglo = (Administrador[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaAdministradores.add(arreglo[i]);
			}
		}
	}

}
