package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Ave;
import co.edu.unbosque.model.AveDTO;

public class AveDAO implements CRUDOperation<Ave, AveDTO> {

	private ArrayList<Ave> listaAves;
	private String NOMBRE_ARCHIVO_SERIALIZADO = "Aves.bin";
	private String NOMBRE_ARCHIVO_TEXTO = "Aves.csv";

	public AveDAO() {
		// El ArrayList sigue siendo de Entidades
		listaAves = new ArrayList<>();
		leerSerializado();
	}

	@Override
	public void crear(AveDTO nuevoDato) {
		listaAves.add(DataMapper.convertirAveDTOAAve(nuevoDato));
		escribirArchivoSerializado();
		escribirArchivo();
	}

	@Override
	public boolean eliminar(int index) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAves.remove(index);
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public boolean actualizar(int index, AveDTO datoActualizado) {
		if (index < 0 || index >= contar()) {
			return false;
		}
		listaAves.set(index, DataMapper.convertirAveDTOAAve(datoActualizado));
		escribirArchivoSerializado();
		escribirArchivo();
		return true;
	}

	@Override
	public String mostrarTodo() {
		if (listaAves.isEmpty()) {
			return "No hay registros de ave.";
		}
		String contenido = "";
		int posicion = 0;
		for (Ave datoActual : listaAves) {
			contenido += "\nAve #" + posicion;
			contenido += "\n   Nombre: " + datoActual.getNombre();
			contenido += "\n   Especie: " + datoActual.getEspecie();
			contenido += "\n   Edad: " + datoActual.getEdad();
			contenido += "\n   Peso: " + datoActual.getPeso();
			contenido += "\n   Es macho: " + (datoActual.isEsMacho() ? "Si" : "No");
			contenido += "\n   Tipo de sangre: " + datoActual.getTIPO_SANGRE();
			contenido += "\n   Tipo de pico: " + datoActual.getTipoPico();
			contenido += "\n   Puede reproducirse: " + (datoActual.isPuedeReproducirse() ? "Si" : "No");
			posicion++;
		}
		return contenido;
	}

	@Override
	public int contar() {
		return listaAves.size();
	}

	public ArrayList<Ave> getListaAves() {
		return listaAves;
	}

	public void setListaAves(ArrayList<Ave> listaAves) {
		this.listaAves = listaAves;
	}

	public String getNOMBRE_ARCHIVO_SERIALIZADO() {
		return NOMBRE_ARCHIVO_SERIALIZADO;
	}

	public void setNOMBRE_ARCHIVO_SERIALIZADO(String nOMBRE_ARCHIVO_SERIALIZADO) {
		this.NOMBRE_ARCHIVO_SERIALIZADO = nOMBRE_ARCHIVO_SERIALIZADO;
	}

	public String getNOMBRE_ARCHIVO_TEXTO() {
		return NOMBRE_ARCHIVO_TEXTO;
	}

	public void setNOMBRE_ARCHIVO_TEXTO(String nOMBRE_ARCHIVO_TEXTO) {
		this.NOMBRE_ARCHIVO_TEXTO = nOMBRE_ARCHIVO_TEXTO;
	}

	public void escribirArchivo() {
		String contenido = "";
		for (Ave ave : listaAves) {
			contenido += ave.getNombre() + ";";
			contenido += ave.getEspecie() + ";";
			contenido += ave.getEdad() + ";";
			contenido += ave.getPeso() + ";";
			contenido += ave.isEsMacho() + ";";
			contenido += ave.getTIPO_SANGRE() + ";";
			contenido += ave.getTipoPico() + ";";
			contenido += ave.isPuedeReproducirse() + "\n";
		}
		FileHandler.crearYEscribirArchivo(NOMBRE_ARCHIVO_TEXTO, contenido);
	}

	public void escribirArchivoSerializado() {
		Ave[] arreglo = new Ave[listaAves.size()];
		for (int i = 0; i < listaAves.size(); i++) {
			arreglo[i] = listaAves.get(i);
		}
		FileHandler.crearYEscribirSerializado(NOMBRE_ARCHIVO_SERIALIZADO, arreglo);
	}

	public void leerSerializado() {
		Object contenido = FileHandler.abrirYleerSerializado(NOMBRE_ARCHIVO_SERIALIZADO);
		listaAves = new ArrayList<Ave>();
		if (contenido != null) {
			Ave[] arreglo = (Ave[]) contenido;
			for (int i = 0; i < arreglo.length; i++) {
				listaAves.add(arreglo[i]);
			}
		}
	}

}
