package co.edu.unbosque.model;

public class PersonaDTO {
	private String nombre;
	private float id;
	private String correoElectronico;
	private int numeroTelefono;
	private String sexo;

	public PersonaDTO() {
		// TODO Auto-generated constructor stub	
	}

	public PersonaDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo) {
		super();
		this.nombre = nombre;
		this.id = id;
		this.correoElectronico = correoElectronico;
		this.numeroTelefono = numeroTelefono;
		this.sexo = sexo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getId() {
		return id;
	}

	public void setId(float id) {
		this.id = id;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public int getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(int numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", id=" + id + ", correoElectronico=" + correoElectronico
				+ ", numeroTelefono=" + numeroTelefono + ", sexo=" + sexo + "]";
	}
	
}

	


