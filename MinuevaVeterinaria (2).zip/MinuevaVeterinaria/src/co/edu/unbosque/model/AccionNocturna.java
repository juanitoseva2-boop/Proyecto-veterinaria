package co.edu.unbosque.model;

public interface AccionNocturna {
	// no se pueden colocar atributos aqui al menos variables.
	// public final int NUMERO_HORAS = 3 ;
	
	public String dormir() ;
		
	
	
	}
	


