package co.edu.unbosque.model;

import java.io.Serializable;

public class Ave extends Animal implements AccionNocturna,AccionOvipara, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7023457757276860932L;
	private final String TIPO_SANGRE = "Caliente";
	private String tipoPico;
	private boolean puedeReproducirse;

	public Ave() {
	}

	public Ave(String tipoPico, boolean puedeReproducirse) {
		super();
		this.tipoPico = tipoPico;
		this.puedeReproducirse = puedeReproducirse;
	}

	public Ave(String nombre, int edad, float peso, boolean esMacho, String especie, String tipoPico,
			boolean puedeReproducirse) {
		super(nombre, edad, peso, esMacho, especie);
		this.tipoPico = tipoPico;
		this.puedeReproducirse = puedeReproducirse;
	}

	public Ave(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super(nombre, edad, peso, esMacho, especie);
	}

	public String getTipoPico() {
		return tipoPico;
	}

	public void setTipoPico(String tipoPico) {
		this.tipoPico = tipoPico;
	}

	public boolean isPuedeReproducirse() {
		return puedeReproducirse;
	}

	public void setPuedeReproducirse(boolean puedeReproducirse) {
		this.puedeReproducirse = puedeReproducirse;
	}

	public String getTIPO_SANGRE() {
		return TIPO_SANGRE;
	}

	@Override
	public String toString() {
		return super.toString() + " - Ave [TIPO_SANGRE=" + TIPO_SANGRE + ", tipoPico=" + tipoPico + ", puedeReproducirse=" + puedeReproducirse
				+ "]";
	}

	@Override
	public String reproducirse(String epoca) {
		if (epoca.equals("primavera")) {
			return "El ave solo puede reproducirse";
		} else if (epoca.equals("invierno")) {
			return "El ave  esta en epoca de reproduccion";
		} else {
			return "El ave no esta en epoca de reproduccion  ";
		}
	}

	@Override
	public String dormir() {
		// TODO Auto-generated method stub
		return "Las aves suelen dormir en un nido";
	}

	@Override
	public String ponerHuevos() {
		// TODO Auto-generated method stub
		return "El ave puede poner huevos dentro";
	}

	@Override
	public String respirar() {
		// TODO Auto-generated method stub
		return "Las aves respiran por el pico ";
	}
}
