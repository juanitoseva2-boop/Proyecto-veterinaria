package co.edu.unbosque.model;

import java.io.Serializable;

public abstract class Animal implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6174661717180813663L;
	private String nombre;
	private int edad;
	private float peso;
	private boolean esMacho;
	private String especie;

	public Animal() {
	}

	public Animal(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.peso = peso;
		this.esMacho = esMacho;
		this.especie = especie;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public boolean isEsMacho() {
		return esMacho;
	}

	public void setEsMacho(boolean esMacho) {
		this.esMacho = esMacho;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public String alimentarse(String alimento) {
		return "Todos los animales pueden alimentarse";
	}

	public String reproducirse(String epoca) {
		return "Todos los animales pueden reproducirse";
	}
	public abstract String respirar();

	@Override
	public String toString() {
		return "Animal [nombre=" + nombre + ", edad=" + edad + ", peso=" + peso + ", esMacho=" + esMacho + ", especie="
				+ especie + "]";
	} 
	
	}


