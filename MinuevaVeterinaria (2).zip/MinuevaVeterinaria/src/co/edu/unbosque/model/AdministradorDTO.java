package co.edu.unbosque.model;

public class AdministradorDTO extends PersonaDTO {
	private String profesion;
	private String experiencia;

	public AdministradorDTO() {
		// TODO Auto-generated constructor stub
	}

	public AdministradorDTO(String profesion, String experiencia) {
		super();
		this.profesion = profesion;
		this.experiencia = experiencia;
	}

	public AdministradorDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo,
			String profesion, String experiencia) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		this.profesion = profesion;
		this.experiencia = experiencia;
	}

	public AdministradorDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String sexo) {
		super(nombre, id, correoElectronico, numeroTelefono, sexo);
		// TODO Auto-generated constructor stub
	}

	public String getProfesion() {
		return profesion;
	}

	public void setProfesion(String profesion) {
		this.profesion = profesion;
	}

	public String getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}

	@Override
	public String toString() {
		return super.toString() + " - Administrador [profesion=" + profesion + ", experiencia=" + experiencia + "]";
	}

}
