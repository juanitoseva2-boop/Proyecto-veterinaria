package co.edu.unbosque.model;

public class MedicamentoDTO extends ProductoDTO {
	private String fechaVencimiento;
	private String tipoMedicamento;
	private float numeroDosis;
	private float temperatura;

	public MedicamentoDTO() {
		// TODO Auto-generated constructor stub
	}

	public MedicamentoDTO(String fechaVencimiento, String tipoMedicamento, float numeroDosis, float temperatura) {
		super();
		this.fechaVencimiento = fechaVencimiento;
		this.tipoMedicamento = tipoMedicamento;
		this.numeroDosis = numeroDosis;
		this.temperatura = temperatura;
	}

	public MedicamentoDTO(String nombre, String color, float precio, int tamano, String fechaVencimiento,
			String tipoMedicamento, float numeroDosis, float temperatura) {
		super(nombre, color, precio, tamano);
		this.fechaVencimiento = fechaVencimiento;
		this.tipoMedicamento = tipoMedicamento;
		this.numeroDosis = numeroDosis;
		this.temperatura = temperatura;
	}

	public MedicamentoDTO(String nombre, String color, float precio, int tamano) {
		super(nombre, color, precio, tamano);
		// TODO Auto-generated constructor stub
	}

	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	public String getTipoMedicamento() {
		return tipoMedicamento;
	}

	public void setTipoMedicamento(String tipoMedicamento) {
		this.tipoMedicamento = tipoMedicamento;
	}

	public float getNumeroDosis() {
		return numeroDosis;
	}

	public void setNumeroDosis(float numeroDosis) {
		this.numeroDosis = numeroDosis;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

	@Override
	public String toString() {
		return super.toString() + " - Medicamento [fechaVencimiento=" + fechaVencimiento + ", tipoMedicamento=" + tipoMedicamento
				+ ", numeroDosis=" + numeroDosis + ", temperatura=" + temperatura + "]";
	}
	


}


