package co.edu.unbosque.model;

public interface AccionMontana {
	
	public String escalar ();
	

}
