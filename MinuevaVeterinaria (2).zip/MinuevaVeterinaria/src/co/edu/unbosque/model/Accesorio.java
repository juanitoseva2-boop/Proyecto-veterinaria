package co.edu.unbosque.model;

import java.io.Serializable;

public class Accesorio extends Producto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7728632957483975175L;
	private String tipoAccesorio;
	private String talla;
	private String parteCuerpo;
	
	public Accesorio() {
		// TODO Auto-generated constructor stub
	}

	public Accesorio(String tipoAccesorio, String talla, String parteCuerpo) {
		super();
		this.tipoAccesorio = tipoAccesorio;
		this.talla = talla;
		this.parteCuerpo = parteCuerpo;
	}

	public Accesorio(String nombre, String color, float precio, int tamano, String tipoAccesorio, String talla,
			String parteCuerpo) {
		super(nombre, color, precio, tamano);
		this.tipoAccesorio = tipoAccesorio;
		this.talla = talla;
		this.parteCuerpo = parteCuerpo;
	}

	public Accesorio(String nombre, String color, float precio, int tamano) {
		super(nombre, color, precio, tamano);
		// TODO Auto-generated constructor stub
	}

	public String getTipoAccesorio() {
		return tipoAccesorio;
	}

	public void setTipoAccesorio(String tipoAccesorio) {
		this.tipoAccesorio = tipoAccesorio;
	}

	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	public String getParteCuerpo() {
		return parteCuerpo;
	}

	public void setParteCuerpo(String parteCuerpo) {
		this.parteCuerpo = parteCuerpo;
	}

	@Override
	public String toString() {
		return super.toString() + " - Accesorio [tipoAccesorio=" + tipoAccesorio + ", talla=" + talla + ", parteCuerpo=" + parteCuerpo + "]";
	}
	
	

}

