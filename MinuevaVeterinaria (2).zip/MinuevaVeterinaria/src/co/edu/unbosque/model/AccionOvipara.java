package co.edu.unbosque.model;

public interface AccionOvipara {
	
public String ponerHuevos();

}
