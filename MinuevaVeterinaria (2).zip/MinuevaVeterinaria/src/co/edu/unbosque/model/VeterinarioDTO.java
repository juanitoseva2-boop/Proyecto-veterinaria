package co.edu.unbosque.model;

public class VeterinarioDTO extends PersonaDTO {
	private String especialidad;
	private String experiencia;
	private String tipoContrato;

	public VeterinarioDTO() {
		// TODO Auto-generated constructor stub
	}

	public VeterinarioDTO(String nombre, float id, String correoElectronico, int numeroTelefono, String especialidad,
			String experiencia, String tipoContrato) {
		super(nombre, id, correoElectronico, numeroTelefono, null);
		this.especialidad = especialidad;
		this.experiencia = experiencia;
		this.tipoContrato = tipoContrato;
	}

	public VeterinarioDTO(String especialidad, String experiencia, String tipoContrato) {
		super();
		this.especialidad = especialidad;
		this.experiencia = experiencia;
		this.tipoContrato = tipoContrato;
	}

	public VeterinarioDTO(String nombre, float id, String correoElectronico, int numeroTelefono) {
		super(nombre, id, correoElectronico, numeroTelefono, null);
		// TODO Auto-generated constructor stub
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public String getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	@Override
	public String toString() {
		return super.toString() + " - Veterinario [especialidad=" + especialidad + ", experiencia=" + experiencia + ", tipoContrato="
				+ tipoContrato + "]";
	}

}
