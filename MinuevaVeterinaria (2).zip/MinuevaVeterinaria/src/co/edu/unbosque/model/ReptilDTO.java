package co.edu.unbosque.model;

public class ReptilDTO extends AnimalDTO implements AccionNocturna,AccionMontana,AccionOvipara {
	private final String TIPO_SANGRE = "Fria";
	private String tipoEscama;
	private boolean esVenenoso;

	public ReptilDTO() {
		
	}

	public ReptilDTO(String tipoEscama, boolean esVenenoso) {
		super();
		this.tipoEscama = tipoEscama;
		this.esVenenoso = esVenenoso;
	}

	public ReptilDTO(String nombre, int edad, float peso, boolean esMacho, String especie, String tipoEscama,
			boolean esVenenoso) {
		super(nombre, edad, peso, esMacho, especie);
		this.tipoEscama = tipoEscama;
		this.esVenenoso = esVenenoso;
	}

	public ReptilDTO(String nombre, int edad, float peso, boolean esMacho, String especie) {
		super(nombre, edad, peso, esMacho, especie);
		// TODO Auto-generated constructor stub
	}
	// constructor vacio de la sub
	// constructor completo de la sub solo (propios)
	// constructor completo con la super
	// constructor intermedio de solo la supér

	public String getTipoEscama() {
		return tipoEscama;
	}

	public void setTipoEscama(String tipoEscama) {
		this.tipoEscama = tipoEscama;
	}

	public boolean isEsVenenoso() {
		return esVenenoso;
	}

	public void setEsVenenoso(boolean esVenenoso) {
		this.esVenenoso = esVenenoso;
	}

	public String getTIPO_SANGRE() {
		return TIPO_SANGRE;
	}

	@Override
	public String toString() {
		return super.toString() + " - Reptil [TIPO_SANGRE=" + TIPO_SANGRE + ", tipoEscama=" + tipoEscama
				+ ", esVenenoso=" + esVenenoso + "]";
	}

	@Override
	public String alimentarse(String alimento) {
		if (alimento.equals("Carne")) {
			return ("El reptil solo puede comer carne");
		} else {
			if (alimento.equals("pollitos")) {
				return ("El reptil  puede alimentarse");
			} else {
				return ("El reptil no se puede  alimentar ");
			}

		}

	}

	@Override
	public String dormir() {
		// TODO Auto-generated method stub
		return "los reptiles por lo general duermen sobre un arbol ";
	}

	@Override
	public String escalar() {
		// TODO Auto-generated method stub
		return "El reptil puede escalar en piedras,montañas,arboles";
	}

	@Override
	public String ponerHuevos() {
		// TODO Auto-generated method stub
		return "El reptil puede poner huevos";
	}

	@Override
	public String respirar() {
		// TODO Auto-generated method stub
		return "El reptil respira por las fosas nasales ";
	}

	

}


