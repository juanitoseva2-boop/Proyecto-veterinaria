package co.edu.unbosque.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Properties;

import co.edu.unbosque.model.Accesorio;
import co.edu.unbosque.model.AccesorioDTO;
import co.edu.unbosque.model.Administrador;
import co.edu.unbosque.model.AdministradorDTO;
import co.edu.unbosque.model.Alimento;
import co.edu.unbosque.model.AlimentoDTO;
import co.edu.unbosque.model.Ave;
import co.edu.unbosque.model.AveDTO;
import co.edu.unbosque.model.Canino;
import co.edu.unbosque.model.CaninoDTO;
import co.edu.unbosque.model.Cliente;
import co.edu.unbosque.model.ClienteDTO;
import co.edu.unbosque.model.Felino;
import co.edu.unbosque.model.FelinoDTO;
import co.edu.unbosque.model.Medicamento;
import co.edu.unbosque.model.MedicamentoDTO;
import co.edu.unbosque.model.Pez;
import co.edu.unbosque.model.PezDTO;
import co.edu.unbosque.model.Reptil;
import co.edu.unbosque.model.ReptilDTO;
import co.edu.unbosque.model.Veterinario;
import co.edu.unbosque.model.VeterinarioDTO;
import co.edu.unbosque.model.persistence.AccesorioDAO;
import co.edu.unbosque.model.persistence.AdministradorDAO;
import co.edu.unbosque.model.persistence.AlimentoDAO;
import co.edu.unbosque.model.persistence.AveDAO;
import co.edu.unbosque.model.persistence.CaninoDAO;
import co.edu.unbosque.model.persistence.ClienteDAO;
import co.edu.unbosque.model.persistence.FelinoDAO;
import co.edu.unbosque.model.persistence.MedicamentoDAO;
import co.edu.unbosque.model.persistence.PezDAO;
import co.edu.unbosque.model.persistence.ReptilDAO;
import co.edu.unbosque.model.persistence.VeterinarioDAO;
import co.edu.unbosque.util.exception.ExceptionChecker;
import co.edu.unbosque.util.exception.GeneroException;
import co.edu.unbosque.util.exception.GreaterThanThousandException;
import co.edu.unbosque.util.exception.MedicamentoException;
import co.edu.unbosque.util.exception.NegativeNumberException;
import co.edu.unbosque.util.exception.NegativeVoidException;
import co.edu.unbosque.util.exception.PrimeNumberException;
import co.edu.unbosque.util.exception.VacunaException;
import co.edu.unbosque.view.Consola;

public class Controlador {
	private Consola con;
	private ReptilDAO reptilDAO;
	private AveDAO aveDAO;
	private PezDAO pezDAO;
	private CaninoDAO caninoDAO;
	private FelinoDAO felinoDAO;
	private ClienteDAO clienteDAO;
	private VeterinarioDAO veterinarioDAO;
	private AdministradorDAO administradorDAO;
	private MedicamentoDAO medicamentoDAO;
	private AlimentoDAO alimentoDAO;
	private AccesorioDAO accesorioDAO;

	public Controlador() {
		con = new Consola();
		reptilDAO = new ReptilDAO();
		aveDAO = new AveDAO();
		pezDAO = new PezDAO();
		caninoDAO = new CaninoDAO();
		felinoDAO = new FelinoDAO();
		clienteDAO = new ClienteDAO();
		veterinarioDAO = new VeterinarioDAO();
		administradorDAO = new AdministradorDAO();
		medicamentoDAO = new MedicamentoDAO();
		alimentoDAO = new AlimentoDAO();
		accesorioDAO = new AccesorioDAO();

	}

	public void arrancar() {
		Properties prop = new Properties();
		con.imprimirConSalto("Seleccione su idioma");
		con.imprimirConSalto("1. Español");
		con.imprimirConSalto("2. English");
		con.imprimirConSalto("3. Italiano");
		con.imprimirConSalto("4. Русский");
		con.imprimirConSalto("5. Français");
		con.imprimirConSalto("6. Polski");
		con.imprimirConSalto("7. Latina");
		con.imprimirConSalto("8. 日本語");

		int opcion = con.leerEntero();

		try {

			switch (opcion) {

			case 1:
				prop.load(new FileInputStream(new File("spanish.properties")));
				break;

			case 2:
				prop.load(new FileInputStream(new File("english.properties")));
				break;
			case 3:
				prop.load(new FileInputStream(new File("italian.properties")));
				break;
			case 4:
				prop.load(new FileInputStream(new File("russian.properties")));
				break;
			case 5:
				prop.load(new FileInputStream(new File("french.properties")));
				break;
			case 6:
				prop.load(new FileInputStream(new File("polish.properties")));
				break;
			case 7:
				prop.load(new FileInputStream(new File("latin.properties")));
				break;
			case 8:
				prop.load(new FileInputStream(new File("japanese.properties")));
				break;
			}

		} catch (FileNotFoundException e) {
			con.imprimirConSalto("El archivo de propiedades no existe");
		} catch (IOException e) {
			con.imprimirConSalto("Error al abrir el archivo de propiedades");
			e.printStackTrace();
		}
	
			switch (opcion) {
			case 1: {
				menuReptil();
				break;
			}
			case 2: {
				menuAve();
				break;
			}
			case 3: {
				menuPez();
				break;
			}
			case 4: {
				menuCanino();
				break;
			}
			case 5: {
				menuFelino();
				break;
			}
			case 6: {
				menuCliente();
				break;
			}
			case 7: {
				menuVeterinario();
				break;
			}
			case 8: {
				menuAdministrador();
				break;
			}
			case 9: {
				menuMedicamento();
				break;
			}
			case 10: {
				menuAlimento();
				break;
			}
			case 11: {
				menuAccesorio();
				break;
			}
			case 99: {
				con.imprimirConSalto("Gracias por usar el aplicativo");
				break cicloMenuPrincipal;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;

			}
		}
	

	public void menuReptil() {

		cicloReptil: while (true) {

			int opcion = 0;
			try {
				con.imprimirConSalto("Menu reptil");
				con.imprimirConSalto("1.Crear nuevo reptil");
				con.imprimirConSalto("2.Eliminar un reptil");
				con.imprimirConSalto("3.Actualizar a un reptil");
				con.imprimirConSalto("4.Mostrar los datos de todos los reptiles");
				con.imprimirConSalto("5.Mostrar informacion de un solo reptil");
				con.imprimirConSalto("99.Volver al menu principal");
				opcion = con.leerEntero();
			} catch (InputMismatchException e) {
				con.imprimirConSalto("Ingreso un caracter invalido");
				con.quemarLinea();
			}

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Reptil");

				con.imprimirConSalto("Inserte el nombre del reptil");
				con.quemarLinea();
				String nombre = con.leerLinea();

				con.imprimirConSalto("Inserte la especie del reptil");
				String especie = con.leerLinea();

				con.imprimirConSalto("Inserte la edad del reptil");
				int edad = con.leerEntero();

				con.imprimirConSalto("Inserte el peso del reptil");
				float peso = con.leerFlotante();
				con.imprimirConSalto("Su reptil es macho?");
				boolean esMacho = con.leerBoleano();
				con.imprimirConSalto("El reptil es venenoso?");
				boolean esVenenoso = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el tipo de escama del reptil");
				String tipoEscama = con.leerLinea();
				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					reptilDAO.crear(new ReptilDTO(nombre, edad, peso, esMacho, especie, tipoEscama, esVenenoso));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}

			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar");
				int index = con.leerEntero();
				if (reptilDAO.eliminar(index)) {
					con.imprimirConSalto("Reptil eliminado con exitó");
				} else {
					con.imprimirConSalto("No se puede eliminar el reptil");

				}
				break;

			}

			case 3: {
				con.imprimirConSalto("Actualizar reptil..");
				con.imprimirConSalto("Ingrese la posicion del reptil a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando un nuevo Reptil");
				con.imprimirConSalto("Inserte el nombre del nuevo reptil");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva especie del reptil");
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte la  nueva edad del reptil");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del reptil");
				float peso = con.leerFlotante();
				con.imprimirConSalto("Su reptil sigue siendo macho?");
				boolean esMacho = con.leerBoleano();
				con.imprimirConSalto("El reptil sigue siendo venenoso?");
				boolean esVenenoso = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de escama del reptil");
				String tipoEscama = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					if (reptilDAO.actualizar(index,
							new ReptilDTO(nombre, edad, peso, esMacho, especie, tipoEscama, esVenenoso))) {
						con.imprimirConSalto("Su reptil a sido actualizado exitosamente ");
					} else {
						con.imprimirConSalto("No se pudo actualizar su Reptill");
					}
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(reptilDAO.mostrarTodo());

				break;
			}

			case 5: {

				con.imprimirConSalto("Mostrar informacion de un solo reptil.");
				con.imprimirConSalto("Ingrese la posicion del reptil que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= reptilDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Reptil reptil = reptilDAO.getListaReptiles().get(index);

					con.imprimirConSalto("Nombre:" + reptil.getNombre());
					con.imprimirConSalto("Peso:" + reptil.getPeso());
					con.imprimirConSalto("Especie:" + reptil.getEspecie());
					con.imprimirConSalto("Edad:" + reptil.getEdad());
					con.imprimirConSalto("Es macho: " + (reptil.isEsMacho() ? "Si" : "No"));
					con.imprimirConSalto("Que tipo de sangre tiene:" + reptil.getTIPO_SANGRE());

				}
				break;
			}
			case 6: {
				con.imprimirConSalto("Dormir");
				if (reptilDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(reptilDAO.getListaReptiles().get(0).dormir());
				}
				break;
			}
			case 7: {
				con.imprimirConSalto("Poner huevos en un nido");
				if (reptilDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(reptilDAO.getListaReptiles().get(0).ponerHuevos());
				}
				break;
			}
			case 8: {
				con.imprimirConSalto("respirar");
				if (reptilDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(reptilDAO.getListaReptiles().get(0).respirar());
				}
				break;
			}

			case 99: {
				break cicloReptil;

			}
			default:

				con.imprimirConSalto("Opcion invalida");
				break;

			}

		}

	}

	public void menuAve() {

		cicloAve: while (true) {
			int opcion = 0;
			try {

				con.imprimirConSalto("Menu ave");
				con.imprimirConSalto("1.Crear nueva ave");
				con.imprimirConSalto("2.Eliminar a una ave");
				con.imprimirConSalto("3.Actualizar un ave");
				con.imprimirConSalto("4.Mostrar los datos de todos las aves");
				con.imprimirConSalto("5.Mostrar informacion de una sola ave");
				con.imprimirConSalto("99.Volver al menu principal");
				opcion = con.leerEntero();
			} catch (InputMismatchException e) {
				con.imprimirConSalto("Ingreso un caracter invalido");
				con.quemarLinea();

			}

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nueva ave");
				con.imprimirConSalto("Inserte la especie del ave");
				con.quemarLinea();
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte el nombre del ave");
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la edad del ave");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del ave");
				float peso = con.leerFlotante();
				con.imprimirConSalto("El ave es macho?");
				boolean esMacho = con.leerBoleano();
				con.imprimirConSalto("El ave puede reproducirse?");
				boolean puedeReproducirse = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el tipo de pico del ave");
				String tipoPico = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					aveDAO.crear(new AveDTO(nombre, edad, peso, esMacho, especie, tipoPico, puedeReproducirse));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;

			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del ave");
				int index = con.leerEntero();
				if (aveDAO.eliminar(index)) {
					con.imprimirConSalto("Ave eliminada con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el ave");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar ave..");
				con.imprimirConSalto("Ingrese la posicion del ave a actualizar");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando la Ave");
				con.imprimirConSalto("Inserte la nueva especie del ave");
				con.quemarLinea();
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo nombre del ave");
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva edad del ave");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del ave");
				float peso = con.leerFlotante();
				con.imprimirConSalto("El ave sigue siendo macho?");
				boolean esMacho = con.leerBoleano();
				con.imprimirConSalto("El ave sigue pudiendo reproducirse?");
				boolean puedeReproducirse = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de pico del ave");
				String tipoPico = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					if (aveDAO.actualizar(index,
							new AveDTO(nombre, edad, peso, esMacho, especie, tipoPico, puedeReproducirse))) {

						con.imprimirConSalto("Su ave ha sido actualizada exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su ave");
					}
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(aveDAO.mostrarTodo());

				break;

			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de una sola ave.");

				con.imprimirConSalto("Ingrese la posicion del ave que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= aveDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Ave ave = aveDAO.getListaAves().get(index);

					con.imprimirConSalto("Nombre:" + ave.getNombre());
					con.imprimirConSalto("Peso:" + ave.getPeso());
					con.imprimirConSalto("Especie:" + ave.getEspecie());
					con.imprimirConSalto("Edad:" + ave.getEdad());
					con.imprimirConSalto("Puede reproducirse: " + (ave.isPuedeReproducirse() ? "Si" : "No"));

				}
				break;
			}
			case 6: {
				con.imprimirConSalto("Dormir");
				if (aveDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(aveDAO.getListaAves().get(0).dormir());
				}
				break;
			}
			case 7: {
				con.imprimirConSalto("Poner huevos en un nido");
				if (aveDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(aveDAO.getListaAves().get(0).ponerHuevos());
				}
				break;
			}
			case 8: {
				con.imprimirConSalto("respirar");
				if (aveDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(aveDAO.getListaAves().get(0).respirar());
				}
				break;
			}

			case 99: {
				break cicloAve;

			}
			default:

				con.imprimirConSalto("Opcion invalida");
				break;

			}

		}
	}

	public void menuPez() {

		cicloPez: while (true) {
			int opcion = 0;
			try {
				con.imprimirConSalto("Menu Pez");
				con.imprimirConSalto("1.Crear nueva Pez");
				con.imprimirConSalto("2.Eliminar a una Pez");
				con.imprimirConSalto("3.Actualizar un Pez");
				con.imprimirConSalto("4.Mostrar los datos de todos las peces");
				con.imprimirConSalto("5.Mostrar informacion de un solo pez");
				con.imprimirConSalto("99.Volver al menu principal");

				opcion = con.leerEntero();
			} catch (InputMismatchException e) {
				con.imprimirConSalto("Ingreso un caracter invalido");
				con.quemarLinea();
			}

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear un nuevo pez");
				con.imprimirConSalto("Inserte la especie del pez");
				con.quemarLinea();
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte el nombre del pez");
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la edad del pez");
				int edad = con.leerEntero();
				con.imprimirConSalto("Cuánto alimento consume el pez al día?");
				float consumoAlimentoDiario = con.leerFlotante();
				con.imprimirConSalto("Inserte el  peso del pez");
				float peso = con.leerFlotante();
				con.imprimirConSalto("El pez es venenoso ?");
				boolean esVenenoso = con.leerBoleano();
				con.imprimirConSalto("El pez es macho ?");
				boolean esMacho = con.leerBoleano();
				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					pezDAO.crear(new PezDTO(nombre, edad, peso, esMacho, especie, esVenenoso, consumoAlimentoDiario));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;

			}
			case 2: {
				con.imprimirConSalto("Eliminar pez... ");
				con.imprimirConSalto("Inserte la posicion a eliminar del pez");
				int index = con.leerEntero();
				if (pezDAO.eliminar(index)) {
					con.imprimirConSalto("pez eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el pez");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Pez..");
				con.imprimirConSalto("Ingrese la posicion del pez a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando un nuevo pez");
				con.imprimirConSalto("Inserte el nombre del nuevo pez");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva especie del pez");
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte la  nueva edad del pez");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte de nuevo la cantidad de alimento que se come el pez ");
				float consumoAlimentoDiario = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo peso del pez");
				float peso = con.leerFlotante();
				con.imprimirConSalto("Inserte si es pez sigue siendo venenoso");
				boolean esVenenoso = con.leerBoleano();
				con.imprimirConSalto("El pez sigue siendo macho ?");
				boolean esMacho = con.leerBoleano();

				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					if (pezDAO.actualizar(index,
							new PezDTO(nombre, edad, peso, esMacho, especie, esVenenoso, consumoAlimentoDiario))) {
						con.imprimirConSalto("Su pez a sido actualizado exitosamente ");

					} else {
						con.imprimirConSalto("No se pudo actualizar su Pez");
					}
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;

			}
			case 4: {

				con.imprimirConSalto(pezDAO.mostrarTodo());

				break;

			}

			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo pez.");

				con.imprimirConSalto("Ingrese la posicion del pez que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= pezDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Pez pez = pezDAO.getListaPeces().get(index);

					con.imprimirConSalto("Nombre:" + pez.getNombre());
					con.imprimirConSalto("Especie:" + pez.getEspecie());
					con.imprimirConSalto("Edad:" + pez.getEdad());
					con.imprimirConSalto("Peso:" + pez.getPeso());
					con.imprimirConSalto("Es venenoso:" + (pez.isEsVenenoso() ? "Si" : "No"));
					con.imprimirConSalto("Consumo de alimento diario:" + (pez.getConsumoAlimentoDiario()));
				}
				break;
			}
			case 6: {
				con.imprimirConSalto("Poner huevos en un nido");
				if (pezDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(pezDAO.getListaPeces().get(0).ponerHuevos());
				}
				break;
			}
			case 7: {
				con.imprimirConSalto("respirar");
				if (pezDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(pezDAO.getListaPeces().get(0).respirar());
				}
				break;
			}

			case 99: {
				break cicloPez;

			}
			default:

				con.imprimirConSalto("Opcion invalida");
				break;

			}

		}
	}

	public void menuCanino() {

		cicloCanino: while (true) {
			int opcion = 0;
			try {
				con.imprimirConSalto("Menu Canino");
				con.imprimirConSalto("1.Crear nueva Canino");
				con.imprimirConSalto("2.Eliminar a una Canino");
				con.imprimirConSalto("3.Actualizar un Canino");
				con.imprimirConSalto("4.Mostrar los datos de todos los Caninos");
				con.imprimirConSalto("5.Mostrar informacion de un solo canino");
				con.imprimirConSalto("99.Volver al menu principal");

				opcion = con.leerEntero();
			} catch (InputMismatchException e) {
				con.imprimirConSalto("Ingreso un caracter invalido");
				con.quemarLinea();
			}

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo canino");
				con.imprimirConSalto("Inserte la especie del canino");
				con.quemarLinea();
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte el nombre del canino");
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la edad del canino");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del canino");
				float peso = con.leerFlotante();
				con.imprimirConSalto("El canino esta vacunado?");
				boolean esVacunado = con.leerBoleano();
				con.imprimirConSalto("El canino es macho?");
				boolean esMacho = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el tipo de pelaje del canino");
				String tipoPelaje = con.leerLinea();
				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					caninoDAO.crear(new CaninoDTO(nombre, edad, peso, esMacho, especie, tipoPelaje, esVacunado));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;

			}
			case 2: {
				con.imprimirConSalto("Eliminar canino... ");
				con.imprimirConSalto("Inserte la posicion a eliminar del canino");
				int index = con.leerEntero();
				if (caninoDAO.eliminar(index)) {
					con.imprimirConSalto("canino eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el canino");
				}
				break;

			}
			case 3: {
				con.imprimirConSalto("Actualizar Canino..");
				con.imprimirConSalto("Ingrese la posicion del canino a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando un nuevo canino");
				con.imprimirConSalto("Inserte el nombre del nuevo canino");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva especie del canino");
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte la  nueva edad del canino");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del canino");
				float peso = con.leerFlotante();
				boolean yaVacunado = index >= 0 && index < caninoDAO.contar()
						&& caninoDAO.getListaCaninos().get(index).isEsVacunado();
				con.imprimirConSalto("Se le aplica la vacuna ahora?");
				boolean aplicarVacuna = con.leerBoleano();
				boolean esVacunado = yaVacunado || aplicarVacuna;
				con.imprimirConSalto("El canino sigue siendo macho?");
				boolean esMacho = con.leerBoleano();
				con.quemarLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de pelaje del canino");
				String tipoPelaje = con.leerLinea();
				try {
					ExceptionChecker.verificarVacuna(yaVacunado && aplicarVacuna);
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					if (caninoDAO.actualizar(index,
							new CaninoDTO(nombre, edad, peso, esMacho, especie, tipoPelaje, esVacunado))) {
						con.imprimirConSalto("Su canino a sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su canino");
					}
				} catch (NegativeNumberException | VacunaException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {

				con.imprimirConSalto(caninoDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo canino.");

				con.imprimirConSalto("Ingrese la posicion del canino que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= caninoDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Canino canino = caninoDAO.getListaCaninos().get(index);

					con.imprimirConSalto("Nombre:" + canino.getNombre());
					con.imprimirConSalto("Especie:" + canino.getEspecie());
					con.imprimirConSalto("Edad:" + canino.getEdad());
					con.imprimirConSalto("Peso:" + canino.getPeso());
					con.imprimirConSalto("Esta vacunado:" + (canino.isEsVacunado() ? "Si" : "No"));
				}
				break;
			}
			case 6: {
				con.imprimirConSalto("Dormir");
				if (caninoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(caninoDAO.getListaCaninos().get(0).dormir());
				}
				break;
			}
			case 7: {
				con.imprimirConSalto("escalar");
				if (caninoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(caninoDAO.getListaCaninos().get(0).escalar());
				}
				break;
			}
			case 8: {
				con.imprimirConSalto("respirar");
				if (caninoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(caninoDAO.getListaCaninos().get(0).respirar());
				}
				break;
			}

			case 99: {
				break cicloCanino;

			}
			default:

				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuFelino() {

		cicloFelino: while (true) {

			con.imprimirConSalto("Menu Felino");
			con.imprimirConSalto("1.Crear nueva Felino");
			con.imprimirConSalto("2.Eliminar a una Felino");
			con.imprimirConSalto("3.Actualizar un Felino");
			con.imprimirConSalto("4.Mostrar los datos de todos los Felinos");
			con.imprimirConSalto("5.Mostrar informacion de un solo felino");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();
			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo felino");
				con.imprimirConSalto("Inserte la especie del felino");
				con.quemarLinea();
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte el nombre del felino");
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el color del pelaje del felino");
				String colorPelaje = con.leerLinea();
				con.imprimirConSalto("Inserte la edad del felino");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del felino");
				float peso = con.leerFlotante();
				con.imprimirConSalto("El felino es domestico?");
				boolean esDomestico = con.leerBoleano();
				con.imprimirConSalto("El felino es macho?");
				boolean esMacho = con.leerBoleano();
				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					felinoDAO.crear(new FelinoDTO(nombre, edad, peso, esMacho, especie, colorPelaje, esDomestico));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Eliminar felino..");
				con.imprimirConSalto("Inserte la posicion a eliminar del felino");
				int index = con.leerEntero();
				if (felinoDAO.eliminar(index)) {
					con.imprimirConSalto("Felino eliminado con exitó");
				} else {
					con.imprimirConSalto("No se puede eliminar el felino");

				}
				break;

			}
			case 3: {

				con.imprimirConSalto("Actualizar Felino..");
				con.imprimirConSalto("Ingrese la posicion del felino a actualizar..");
				int index = con.leerEntero();
				con.imprimirConSalto("Actualizando un nuevo felino");
				con.imprimirConSalto("Inserte el nombre del nuevo felino");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo color del pelaje del felino");
				String colorPelaje = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva especie del felino");
				String especie = con.leerLinea();
				con.imprimirConSalto("Inserte la  nueva edad del felino");
				int edad = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo peso del felino");
				float peso = con.leerFlotante();
				con.imprimirConSalto("Inserte si el felino  es domestico");
				boolean esDomestico = con.leerBoleano();
				con.imprimirConSalto("El felino sigue siendo macho?");
				boolean esMacho = con.leerBoleano();
				try {
					ExceptionChecker.verificarNumeroNegativo(peso);
					ExceptionChecker.verificarNumeroNegativo(edad);
					if (felinoDAO.actualizar(index,
							new FelinoDTO(nombre, edad, peso, esMacho, especie, colorPelaje, esDomestico))) {
						con.imprimirConSalto("Su felino a sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su felino");
					}
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {

				con.imprimirConSalto(felinoDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo felino.");

				con.imprimirConSalto("Ingrese la posicion del felino que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= felinoDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Felino felino = felinoDAO.getListaFelinos().get(index);

					con.imprimirConSalto("Nombre:" + felino.getNombre());
					con.imprimirConSalto("Color Pelaje:" + felino.getColorPelaje());
					con.imprimirConSalto("Especie:" + felino.getEspecie());
					con.imprimirConSalto("Edad:" + felino.getEdad());
					con.imprimirConSalto("Peso:" + felino.getPeso());
					con.imprimirConSalto("Es Domestico:" + (felino.isEsDomestico() ? "Si" : "No"));
				}
				break;
			}
			case 6: {
				con.imprimirConSalto("Dormir");
				if (felinoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(felinoDAO.getListaFelinos().get(0).dormir());
				}
				break;
			}
			case 7: {
				con.imprimirConSalto("escalar");
				if (felinoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(felinoDAO.getListaFelinos().get(0).escalar());
				}
				break;
			}
			case 8: {
				con.imprimirConSalto("respirar");
				if (felinoDAO.contar() == 0) {
					con.imprimirConSalto("No hay registros");
				} else {
					con.imprimirConSalto(felinoDAO.getListaFelinos().get(0).respirar());
				}
				break;
			}

			case 99: {
				break cicloFelino;

			}
			default:

				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuCliente() {

		cicloCliente: while (true) {

			con.imprimirConSalto("Menu Cliente");
			con.imprimirConSalto("1.Crear nuevo Cliente");
			con.imprimirConSalto("2.Eliminar un Cliente");
			con.imprimirConSalto("3.Actualizar un Cliente");
			con.imprimirConSalto("4.Mostrar los datos de todos los Clientes");
			con.imprimirConSalto("5.Mostrar informacion de un solo Cliente");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Cliente");
				con.imprimirConSalto("Inserte el nombre del cliente");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el id del cliente");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el correo electronico del cliente");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el numero de telefono del cliente");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte el sexo del cliente");
				con.quemarLinea();
				String sexo = con.leerLinea();
				con.imprimirConSalto("Inserte el nombre de la mascota del cliente");
				String nombreMascota = con.leerLinea();
				con.imprimirConSalto("Inserte el tipo de animal de la mascota del cliente");
				String tipoAnimal = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					ExceptionChecker.verificarGenero(sexo);
					clienteDAO.crear(new ClienteDTO(nombre, id, correoElectronico, numeroTelefono, sexo, nombreMascota,
							tipoAnimal));
				} catch (GeneroException | NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del cliente");
				int index = con.leerEntero();
				if (clienteDAO.eliminar(index)) {
					con.imprimirConSalto("Cliente eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el cliente");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Cliente..");
				con.imprimirConSalto("Ingrese la posicion del cliente a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Cliente");
				con.imprimirConSalto("Inserte el nuevo nombre del cliente");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo id del cliente");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo correo electronico del cliente");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo numero de telefono del cliente");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo sexo del cliente");
				con.quemarLinea();
				String sexo = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo nombre de la mascota del cliente");
				String nombreMascota = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de animal de la mascota del cliente");
				String tipoAnimal = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					ExceptionChecker.verificarGenero(sexo);
					if (clienteDAO.actualizar(index, new ClienteDTO(nombre, id, correoElectronico, numeroTelefono, sexo,
							nombreMascota, tipoAnimal))) {
						con.imprimirConSalto("Su cliente ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su cliente");
					}
				} catch (GeneroException | NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(clienteDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo cliente.");
				con.imprimirConSalto("Ingrese la posicion del cliente que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= clienteDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Cliente cliente = clienteDAO.getListaClientes().get(index);

					con.imprimirConSalto("Nombre:" + cliente.getNombre());
					con.imprimirConSalto("Id:" + cliente.getId());
					con.imprimirConSalto("Correo electronico:" + cliente.getCorreoElectronico());
					con.imprimirConSalto("Numero de telefono:" + cliente.getNumeroTelefono());
					con.imprimirConSalto("Sexo:" + cliente.getSexo());
					con.imprimirConSalto("Nombre de la mascota:" + cliente.getNombreMascota());
					con.imprimirConSalto("Tipo de animal:" + cliente.getTipoAnimal());
				}
				break;
			}
			case 99: {
				break cicloCliente;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuVeterinario() {

		cicloVeterinario: while (true) {

			con.imprimirConSalto("Menu Veterinario");
			con.imprimirConSalto("1.Crear nuevo Veterinario");
			con.imprimirConSalto("2.Eliminar un Veterinario");
			con.imprimirConSalto("3.Actualizar un Veterinario");
			con.imprimirConSalto("4.Mostrar los datos de todos los Veterinarios");
			con.imprimirConSalto("5.Mostrar informacion de un solo Veterinario");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Veterinario");
				con.imprimirConSalto("Inserte el nombre del veterinario");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el id del veterinario");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el correo electronico del veterinario");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el numero de telefono del veterinario");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte la especialidad del veterinario");
				con.quemarLinea();
				String especialidad = con.leerLinea();
				con.imprimirConSalto("Inserte la experiencia del veterinario");
				String experiencia = con.leerLinea();
				con.imprimirConSalto("Inserte el tipo de contrato del veterinario");
				String tipoContrato = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					veterinarioDAO.crear(new VeterinarioDTO(nombre, id, correoElectronico, numeroTelefono, especialidad,
							experiencia, tipoContrato));
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del veterinario");
				int index = con.leerEntero();
				if (veterinarioDAO.eliminar(index)) {
					con.imprimirConSalto("Veterinario eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el veterinario");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Veterinario..");
				con.imprimirConSalto("Ingrese la posicion del veterinario a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Veterinario");
				con.imprimirConSalto("Inserte el nuevo nombre del veterinario");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo id del veterinario");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo correo electronico del veterinario");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo numero de telefono del veterinario");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte la nueva especialidad del veterinario");
				con.quemarLinea();
				String especialidad = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva experiencia del veterinario");
				String experiencia = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de contrato del veterinario");
				String tipoContrato = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					if (veterinarioDAO.actualizar(index, new VeterinarioDTO(nombre, id, correoElectronico,
							numeroTelefono, especialidad, experiencia, tipoContrato))) {
						con.imprimirConSalto("Su veterinario ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su veterinario");
					}
				} catch (NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(veterinarioDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo veterinario.");
				con.imprimirConSalto("Ingrese la posicion del veterinario que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= veterinarioDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Veterinario veterinario = veterinarioDAO.getListaVeterinarios().get(index);

					con.imprimirConSalto("Nombre:" + veterinario.getNombre());
					con.imprimirConSalto("Id:" + veterinario.getId());
					con.imprimirConSalto("Correo electronico:" + veterinario.getCorreoElectronico());
					con.imprimirConSalto("Numero de telefono:" + veterinario.getNumeroTelefono());
					con.imprimirConSalto("Especialidad:" + veterinario.getEspecialidad());
					con.imprimirConSalto("Experiencia:" + veterinario.getExperiencia());
					con.imprimirConSalto("Tipo de contrato:" + veterinario.getTipoContrato());
				}
				break;
			}
			case 99: {
				break cicloVeterinario;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuAdministrador() {

		cicloAdministrador: while (true) {

			con.imprimirConSalto("Menu Administrador");
			con.imprimirConSalto("1.Crear nuevo Administrador");
			con.imprimirConSalto("2.Eliminar un Administrador");
			con.imprimirConSalto("3.Actualizar un Administrador");
			con.imprimirConSalto("4.Mostrar los datos de todos los Administradores");
			con.imprimirConSalto("5.Mostrar informacion de un solo Administrador");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Administrador");
				con.imprimirConSalto("Inserte el nombre del administrador");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el id del administrador");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el correo electronico del administrador");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el numero de telefono del administrador");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte el sexo del administrador");
				con.quemarLinea();
				String sexo = con.leerLinea();
				con.imprimirConSalto("Inserte la profesion del administrador");
				String profesion = con.leerLinea();
				con.imprimirConSalto("Inserte la experiencia del administrador");
				String experiencia = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					ExceptionChecker.verificarGenero(sexo);
					administradorDAO.crear(new AdministradorDTO(nombre, id, correoElectronico, numeroTelefono, sexo,
							profesion, experiencia));
				} catch (GeneroException | NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del administrador");
				int index = con.leerEntero();
				if (administradorDAO.eliminar(index)) {
					con.imprimirConSalto("Administrador eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el administrador");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Administrador..");
				con.imprimirConSalto("Ingrese la posicion del administrador a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Administrador");
				con.imprimirConSalto("Inserte el nuevo nombre del administrador");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo id del administrador");
				float id = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo correo electronico del administrador");
				con.quemarLinea();
				String correoElectronico = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo numero de telefono del administrador");
				int numeroTelefono = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo sexo del administrador");
				con.quemarLinea();
				String sexo = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva profesion del administrador");
				String profesion = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva experiencia del administrador");
				String experiencia = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(id);
					ExceptionChecker.verificarNumeroNegativo(numeroTelefono);
					ExceptionChecker.verificarGenero(sexo);
					if (administradorDAO.actualizar(index, new AdministradorDTO(nombre, id, correoElectronico,
							numeroTelefono, sexo, profesion, experiencia))) {
						con.imprimirConSalto("Su administrador ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su administrador");
					}
				} catch (GeneroException | NegativeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(administradorDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo administrador.");
				con.imprimirConSalto("Ingrese la posicion del administrador que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= administradorDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Administrador administrador = administradorDAO.getListaAdministradores().get(index);

					con.imprimirConSalto("Nombre:" + administrador.getNombre());
					con.imprimirConSalto("Id:" + administrador.getId());
					con.imprimirConSalto("Correo electronico:" + administrador.getCorreoElectronico());
					con.imprimirConSalto("Numero de telefono:" + administrador.getNumeroTelefono());
					con.imprimirConSalto("Sexo:" + administrador.getSexo());
					con.imprimirConSalto("Profesion:" + administrador.getProfesion());
					con.imprimirConSalto("Experiencia:" + administrador.getExperiencia());
				}
				break;
			}
			case 99: {
				break cicloAdministrador;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuMedicamento() {

		cicloMedicamento: while (true) {

			con.imprimirConSalto("Menu Medicamento");
			con.imprimirConSalto("1.Crear nuevo Medicamento");
			con.imprimirConSalto("2.Eliminar un Medicamento");
			con.imprimirConSalto("3.Actualizar un Medicamento");
			con.imprimirConSalto("4.Mostrar los datos de todos los Medicamentos");
			con.imprimirConSalto("5.Mostrar informacion de un solo Medicamento");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Medicamento");
				con.imprimirConSalto("Inserte el nombre del medicamento");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el color del medicamento");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el precio del medicamento");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el tamano del medicamento");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte la fecha de vencimiento del medicamento");
				con.quemarLinea();
				String fechaVencimiento = con.leerLinea();
				con.imprimirConSalto("Inserte el tipo de medicamento");
				String tipoMedicamento = con.leerLinea();
				con.imprimirConSalto("Inserte el numero de dosis del medicamento");
				float numeroDosis = con.leerFlotante();
				con.imprimirConSalto("Inserte la temperatura de almacenamiento del medicamento");
				float temperatura = con.leerFlotante();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					ExceptionChecker.verificarMedicamento(numeroDosis);
					medicamentoDAO.crear(new MedicamentoDTO(nombre, color, precio, tamano, fechaVencimiento,
							tipoMedicamento, numeroDosis, temperatura));
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException
						| MedicamentoException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del medicamento");
				int index = con.leerEntero();
				if (medicamentoDAO.eliminar(index)) {
					con.imprimirConSalto("Medicamento eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el medicamento");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Medicamento..");
				con.imprimirConSalto("Ingrese la posicion del medicamento a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Medicamento");
				con.imprimirConSalto("Inserte el nuevo nombre del medicamento");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo color del medicamento");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo precio del medicamento");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo tamano del medicamento");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte la nueva fecha de vencimiento del medicamento");
				con.quemarLinea();
				String fechaVencimiento = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo tipo de medicamento");
				String tipoMedicamento = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo numero de dosis del medicamento");
				float numeroDosis = con.leerFlotante();
				con.imprimirConSalto("Inserte la nueva temperatura de almacenamiento del medicamento");
				float temperatura = con.leerFlotante();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					ExceptionChecker.verificarMedicamento(numeroDosis);
					if (medicamentoDAO.actualizar(index, new MedicamentoDTO(nombre, color, precio, tamano,
							fechaVencimiento, tipoMedicamento, numeroDosis, temperatura))) {
						con.imprimirConSalto("Su medicamento ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su medicamento");
					}
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException
						| MedicamentoException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(medicamentoDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo medicamento.");
				con.imprimirConSalto("Ingrese la posicion del medicamento que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= medicamentoDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Medicamento medicamento = medicamentoDAO.getListaMedicamentos().get(index);

					con.imprimirConSalto("Nombre:" + medicamento.getNombre());
					con.imprimirConSalto("Color:" + medicamento.getColor());
					con.imprimirConSalto("Precio:" + medicamento.getPrecio());
					con.imprimirConSalto("Tamano:" + medicamento.getTamano());
					con.imprimirConSalto("Fecha de vencimiento:" + medicamento.getFechaVencimiento());
					con.imprimirConSalto("Tipo de medicamento:" + medicamento.getTipoMedicamento());
					con.imprimirConSalto("Numero de dosis:" + medicamento.getNumeroDosis());
					con.imprimirConSalto("Temperatura:" + medicamento.getTemperatura());
				}
				break;
			}
			case 99: {
				break cicloMedicamento;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuAlimento() {

		cicloAlimento: while (true) {

			con.imprimirConSalto("Menu Alimento");
			con.imprimirConSalto("1.Crear nuevo Alimento");
			con.imprimirConSalto("2.Eliminar un Alimento");
			con.imprimirConSalto("3.Actualizar un Alimento");
			con.imprimirConSalto("4.Mostrar los datos de todos los Alimentos");
			con.imprimirConSalto("5.Mostrar informacion de un solo Alimento");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Alimento");
				con.imprimirConSalto("Inserte el nombre del alimento");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el color del alimento");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el precio del alimento");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el tamano del alimento");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte el tipo de alimento");
				con.quemarLinea();
				String tipoAlimento = con.leerLinea();
				con.imprimirConSalto("Inserte el peso del alimento");
				int peso = con.leerEntero();
				con.imprimirConSalto("El alimento es vegano?");
				boolean esVegano = con.leerBoleano();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					ExceptionChecker.verificarNegativeVoid(peso);
					alimentoDAO.crear(new AlimentoDTO(nombre, color, precio, tamano, tipoAlimento, peso, esVegano));
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException
						| NegativeVoidException e) {
					con.imprimirConSalto(e.getMessage());
				}

				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del alimento");
				int index = con.leerEntero();
				if (alimentoDAO.eliminar(index)) {
					con.imprimirConSalto("Alimento eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el alimento");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Alimento..");
				con.imprimirConSalto("Ingrese la posicion del alimento a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Alimento");
				con.imprimirConSalto("Inserte el nuevo nombre del alimento");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo color del alimento");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo precio del alimento");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo tamano del alimento");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo tipo de alimento");
				con.quemarLinea();
				String tipoAlimento = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo peso del alimento");
				int peso = con.leerEntero();
				con.imprimirConSalto("El alimento sigue siendo vegano?");
				boolean esVegano = con.leerBoleano();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					ExceptionChecker.verificarNegativeVoid(peso);
					if (alimentoDAO.actualizar(index,
							new AlimentoDTO(nombre, color, precio, tamano, tipoAlimento, peso, esVegano))) {
						con.imprimirConSalto("Su alimento ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su alimento");
					}
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException
						| NegativeVoidException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(alimentoDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo alimento.");
				con.imprimirConSalto("Ingrese la posicion del alimento que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= alimentoDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Alimento alimento = alimentoDAO.getListaAlimentos().get(index);

					con.imprimirConSalto("Nombre:" + alimento.getNombre());
					con.imprimirConSalto("Color:" + alimento.getColor());
					con.imprimirConSalto("Precio:" + alimento.getPrecio());
					con.imprimirConSalto("Tamano:" + alimento.getTamano());
					con.imprimirConSalto("Tipo de alimento:" + alimento.getTipoAlimento());
					con.imprimirConSalto("Peso:" + alimento.getPeso());
					con.imprimirConSalto("Es vegano:" + (alimento.isEsVegano() ? "Si" : "No"));
				}
				break;
			}
			case 99: {
				break cicloAlimento;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}

	public void menuAccesorio() {

		cicloAccesorio: while (true) {

			con.imprimirConSalto("Menu Accesorio");
			con.imprimirConSalto("1.Crear nuevo Accesorio");
			con.imprimirConSalto("2.Eliminar un Accesorio");
			con.imprimirConSalto("3.Actualizar un Accesorio");
			con.imprimirConSalto("4.Mostrar los datos de todos los Accesorios");
			con.imprimirConSalto("5.Mostrar informacion de un solo Accesorio");
			con.imprimirConSalto("99.Volver al menu principal");

			int opcion = con.leerEntero();

			switch (opcion) {
			case 1: {
				con.imprimirConSalto("Crear nuevo Accesorio");
				con.imprimirConSalto("Inserte el nombre del accesorio");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el color del accesorio");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el precio del accesorio");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el tamano del accesorio");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte el tipo de accesorio");
				con.quemarLinea();
				String tipoAccesorio = con.leerLinea();
				con.imprimirConSalto("Inserte la talla del accesorio");
				String talla = con.leerLinea();
				con.imprimirConSalto("Inserte la parte del cuerpo donde va el accesorio");
				String parteCuerpo = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					accesorioDAO
							.crear(new AccesorioDTO(nombre, color, precio, tamano, tipoAccesorio, talla, parteCuerpo));
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 2: {
				con.imprimirConSalto("Inserte la posicion a eliminar del accesorio");
				int index = con.leerEntero();
				if (accesorioDAO.eliminar(index)) {
					con.imprimirConSalto("Accesorio eliminado con exito");
				} else {
					con.imprimirConSalto("No se puede eliminar el accesorio");
				}
				break;
			}
			case 3: {
				con.imprimirConSalto("Actualizar Accesorio..");
				con.imprimirConSalto("Ingrese la posicion del accesorio a actualizar..");
				int index = con.leerEntero();

				con.imprimirConSalto("Actualizando el Accesorio");
				con.imprimirConSalto("Inserte el nuevo nombre del accesorio");
				con.quemarLinea();
				String nombre = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo color del accesorio");
				String color = con.leerLinea();
				con.imprimirConSalto("Inserte el nuevo precio del accesorio");
				float precio = con.leerFlotante();
				con.imprimirConSalto("Inserte el nuevo tamano del accesorio");
				int tamano = con.leerEntero();
				con.imprimirConSalto("Inserte el nuevo tipo de accesorio");
				con.quemarLinea();
				String tipoAccesorio = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva talla del accesorio");
				String talla = con.leerLinea();
				con.imprimirConSalto("Inserte la nueva parte del cuerpo donde va el accesorio");
				String parteCuerpo = con.leerLinea();

				try {
					ExceptionChecker.verificarNumeroNegativo(precio);
					ExceptionChecker.verificarNumeroMayoraMil(precio);
					ExceptionChecker.verificarNumeroPrimo(tamano);
					if (accesorioDAO.actualizar(index,
							new AccesorioDTO(nombre, color, precio, tamano, tipoAccesorio, talla, parteCuerpo))) {
						con.imprimirConSalto("Su accesorio ha sido actualizado exitosamente");
					} else {
						con.imprimirConSalto("No se pudo actualizar su accesorio");
					}
				} catch (NegativeNumberException | GreaterThanThousandException | PrimeNumberException e) {
					con.imprimirConSalto(e.getMessage());
				}
				break;
			}
			case 4: {
				con.imprimirConSalto(accesorioDAO.mostrarTodo());
				break;
			}
			case 5: {
				con.imprimirConSalto("Mostrar informacion de un solo accesorio.");
				con.imprimirConSalto("Ingrese la posicion del accesorio que deseas consultar:");

				int index = con.leerEntero();
				if (index < 0 || index >= accesorioDAO.contar()) {
					con.imprimirConSalto("La posicion que fue ingresada no existe.");

				} else {
					Accesorio accesorio = accesorioDAO.getListaAccesorios().get(index);

					con.imprimirConSalto("Nombre:" + accesorio.getNombre());
					con.imprimirConSalto("Color:" + accesorio.getColor());
					con.imprimirConSalto("Precio:" + accesorio.getPrecio());
					con.imprimirConSalto("Tamano:" + accesorio.getTamano());
					con.imprimirConSalto("Tipo de accesorio:" + accesorio.getTipoAccesorio());
					con.imprimirConSalto("Talla:" + accesorio.getTalla());
					con.imprimirConSalto("Parte del cuerpo:" + accesorio.getParteCuerpo());
				}
				break;
			}
			case 99: {
				break cicloAccesorio;
			}
			default:
				con.imprimirConSalto("Opcion invalida");
				break;
			}
		}
	}
}