package co.edu.unbosque.util.exception;

public class GreaterThanThousandException  extends Exception{

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 5589904299058444292L;

	public GreaterThanThousandException() {
		super("El numero ingresado no puede ser mayor a mil");
	}
}
