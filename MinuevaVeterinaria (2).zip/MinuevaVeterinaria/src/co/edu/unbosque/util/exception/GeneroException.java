package co.edu.unbosque.util.exception;

public class GeneroException  extends Exception {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1687742463286110822L;

	public GeneroException() {
		super("El genero ingresado no es valido (use M, F o H)");
	}
}
