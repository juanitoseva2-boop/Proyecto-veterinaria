package co.edu.unbosque.util.exception;

public class ExceptionChecker {

	public static void verificarNumeroNegativo(double numero) throws NegativeNumberException {
		if (numero < 0) {
			throw new NegativeNumberException();

		}
	}

	public static void verificarNumeroMayoraMil(double numero) throws GreaterThanThousandException {
		if (numero > 1000) {
			throw new GreaterThanThousandException();

		}

	}

	public static void verificarNumeroPrimo(int numero) throws PrimeNumberException {
	    int divisores = 0;

	    for (int i = 1; i <= numero; i++) {
	        if (numero % i == 0) {
	            divisores++;
	        }
	    }

	    if (numero < 2 || divisores != 2) {
	        throw new PrimeNumberException();

	    }
	}
	public static void verificarNegativeVoid(int numero )throws NegativeVoidException {
		if(numero < 0) {
			throw new NegativeVoidException();
		}
			
		}
	public static void verificarGenero(String genero ) throws GeneroException {
		if (genero == null) {
			throw new GeneroException();
		}
		if(genero.equalsIgnoreCase("M")) {
			return;
		} else if (genero.equalsIgnoreCase("F")) {
			return;
		} else if(genero.equalsIgnoreCase("H")) {
			return;
		}else {
		throw new GeneroException();
	}
	
	}
	public static void verificarMedicamento(double cantidad) throws MedicamentoException {
		if(cantidad <= 0) {
			throw new MedicamentoException();
		}
	}
	public static void verificarVacuna(boolean aplicada ) throws VacunaException { 
	if(aplicada) {
		throw new VacunaException();
	}
		
	}
}


