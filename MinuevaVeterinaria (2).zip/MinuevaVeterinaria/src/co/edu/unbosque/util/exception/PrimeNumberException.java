package co.edu.unbosque.util.exception;

public class PrimeNumberException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3381261088991957355L;

	public PrimeNumberException() {
		super("El numero ingresado no puede ser primo");
		
	
	}
}
