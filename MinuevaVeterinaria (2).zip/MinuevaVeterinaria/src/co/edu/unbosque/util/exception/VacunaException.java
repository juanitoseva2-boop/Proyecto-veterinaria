package co.edu.unbosque.util.exception;

public class VacunaException  extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9083875500966005654L;

	public VacunaException() {
		super("La vacuna ha sido aplicada");
	}

}
