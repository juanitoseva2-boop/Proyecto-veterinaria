package co.edu.unbosque.util.exception;

public class NegativeVoidException  extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6140996739207840692L;

	public NegativeVoidException() {
		super("El valor ingresado no puede ser negativo");
		
	}
	
	}


