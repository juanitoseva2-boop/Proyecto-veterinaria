package co.edu.unbosque.util.exception;

public class MedicamentoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6697747847866920846L;

	public MedicamentoException () {
		super("La cantidad de medicamento es erronea");
		
	}
}
