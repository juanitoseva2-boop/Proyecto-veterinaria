package co.edu.unbosque.view;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Consola {
	private Scanner lector;

	public Consola() {
		lector = new Scanner(System.in);

	}

	public int leerEntero() {
		while (true) {
			try {
				return lector.nextInt();
			} catch (InputMismatchException e) {
				lector.next();
				imprimirConSalto("Ingreso un caracter invalido, intente de nuevo");
			}
		}
	}

	public long leerLargo() {
		while (true) {
			try {
				return lector.nextLong();
			} catch (InputMismatchException e) {
				lector.next();
				imprimirConSalto("Ingreso un caracter invalido, intente de nuevo");
			}
		}
	}

	public float leerFlotante() {
		while (true) {
			try {
				return lector.nextFloat();
			} catch (InputMismatchException e) {
				lector.next();
				imprimirConSalto("Ingreso un caracter invalido, intente de nuevo");
			}
		}
	}

	public double leerDouble() {
		while (true) {
			try {
				return lector.nextDouble();
			} catch (InputMismatchException e) {
				lector.next();
				imprimirConSalto("Ingreso un caracter invalido, intente de nuevo");
			}
		}
	}

	public String leerPalabra() {
		return lector.next();

	}

	public String leerLinea() {
		return lector.nextLine();
	}

	public boolean leerBoleano() {
		String valor = leerPalabra();
		if (valor.toLowerCase().contains("si")) {
			return true;
		} else {
			return false;

		}
	}

	public void imprimirConSalto(String texto) {
		System.out.println(texto);
	}

	public void imprimirSinSalto(String texto) {
		System.out.print(texto + " ");
	}

	public void quemarLinea() {
		lector.nextLine();
		
		
	}
}
